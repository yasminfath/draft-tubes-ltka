import type { CloudFunction } from "@google-cloud/functions-framework"
import { ImageAnnotatorClient } from "@google-cloud/vision"
import { VideoIntelligenceServiceClient } from "@google-cloud/video-intelligence"
import { SpeechClient } from "@google-cloud/speech"
import { Firestore } from "@google-cloud/firestore"

const visionClient = new ImageAnnotatorClient()
const videoClient = new VideoIntelligenceServiceClient()
const speechClient = new SpeechClient()
const firestore = new Firestore()

export const analyzeFile: CloudFunction = async (message, context) => {
  try {
    const data = JSON.parse(message.data.toString())
    const { bucket, fileName, fileType, fileId } = data

    console.log(`Analyzing ${fileType} file: ${fileName}`)

    // Update status to processing
    await updateFileStatus(fileId, "processing")

    let analysis = {}

    switch (fileType) {
      case "image":
        analysis = await analyzeImage(bucket, fileName)
        break
      case "video":
        analysis = await analyzeVideo(bucket, fileName)
        break
      case "audio":
        analysis = await analyzeAudio(bucket, fileName)
        break
    }

    // Store analysis results
    await firestore.collection("files").doc(fileId).update({
      aiAnalysis: analysis,
      status: "completed",
      updatedAt: new Date(),
    })

    console.log(`Completed analysis for: ${fileId}`)
  } catch (error) {
    console.error("Error analyzing file:", error)

    // Update status to error
    const data = JSON.parse(message.data.toString())
    await updateFileStatus(data.fileId, "error")
  }
}

async function analyzeImage(bucket: string, fileName: string) {
  const gcsUri = `gs://${bucket}/${fileName}`

  const [result] = await visionClient.annotateImage({
    image: { source: { gcsImageUri: gcsUri } },
    features: [
      { type: "LABEL_DETECTION", maxResults: 10 },
      { type: "OBJECT_LOCALIZATION", maxResults: 10 },
      { type: "TEXT_DETECTION" },
      { type: "SAFE_SEARCH_DETECTION" },
    ],
  })

  const tags = result.labelAnnotations?.map((label) => label.description || "") || []
  const objects = result.localizedObjectAnnotations?.map((obj) => obj.name || "") || []
  const text = result.textAnnotations?.[0]?.description || ""

  return {
    tags: [...new Set([...tags, ...objects])], // Remove duplicates
    extractedText: text,
    safeSearch: result.safeSearchAnnotation,
  }
}

async function analyzeVideo(bucket: string, fileName: string) {
  const gcsUri = `gs://${bucket}/${fileName}`

  const [operation] = await videoClient.annotateVideo({
    inputUri: gcsUri,
    features: ["LABEL_DETECTION", "SHOT_CHANGE_DETECTION", "SPEECH_TRANSCRIPTION"],
    videoContext: {
      speechTranscriptionConfig: {
        languageCode: "en-US",
        enableAutomaticPunctuation: true,
      },
    },
  })

  const [result] = await operation.promise()

  const tags =
    result.annotationResults?.[0]?.segmentLabelAnnotations?.map((label) => label.entity?.description || "") || []

  const scenes =
    result.annotationResults?.[0]?.shotLabelAnnotations?.map((shot) => shot.entity?.description || "") || []

  const transcript =
    result.annotationResults?.[0]?.speechTranscriptions
      ?.map((transcription) => transcription.alternatives?.[0]?.transcript || "")
      .join(" ") || ""

  return {
    tags: [...new Set(tags)],
    scenes: [...new Set(scenes)],
    transcript,
  }
}

async function analyzeAudio(bucket: string, fileName: string) {
  const gcsUri = `gs://${bucket}/${fileName}`

  const [operation] = await speechClient.longRunningRecognize({
    config: {
      encoding: "FLAC",
      sampleRateHertz: 16000,
      languageCode: "en-US",
      enableAutomaticPunctuation: true,
      enableWordTimeOffsets: true,
    },
    audio: { uri: gcsUri },
  })

  const [result] = await operation.promise()

  const transcript = result.results?.map((result) => result.alternatives?.[0]?.transcript || "").join(" ") || ""

  const words = result.results?.flatMap((result) => result.alternatives?.[0]?.words || []) || []

  return {
    transcript,
    wordCount: words.length,
    duration: words.length > 0 ? Number.parseFloat(words[words.length - 1].endTime?.seconds || "0") : 0,
  }
}

async function updateFileStatus(fileId: string, status: string): Promise<void> {
  await firestore.collection("files").doc(fileId).update({
    status,
    updatedAt: new Date(),
  })
}

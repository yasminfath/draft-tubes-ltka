import { type NextRequest, NextResponse } from "next/server"
import { Storage } from "@google-cloud/storage"
import { Firestore } from "@google-cloud/firestore"

const storage = new Storage({
  projectId: process.env.GOOGLE_CLOUD_PROJECT_ID,
  keyFilename: process.env.GOOGLE_CLOUD_KEY_FILE,
})

const firestore = new Firestore({
  projectId: process.env.GOOGLE_CLOUD_PROJECT_ID,
  keyFilename: process.env.GOOGLE_CLOUD_KEY_FILE,
})

const BUCKET_NAME = process.env.GCS_BUCKET_NAME || "media-library-uploads"

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const fileId = params.id

    console.log(`Deleting file: ${fileId}`)

    // Get file document from Firestore
    const fileDoc = await firestore.collection("files").doc(fileId).get()

    if (!fileDoc.exists) {
      return NextResponse.json({ error: "File not found" }, { status: 404 })
    }

    const fileData = fileDoc.data()

    // Delete file from GCS bucket
    const bucket = storage.bucket(BUCKET_NAME)
    const file = bucket.file(fileData?.fileName || fileId)

    try {
      await file.delete()
      console.log(`File deleted from bucket: ${fileData?.fileName}`)
    } catch (error) {
      console.warn(`File not found in bucket: ${fileData?.fileName}`, error)
      // Continue with Firestore deletion even if GCS deletion fails
    }

    // Delete file document from Firestore
    await firestore.collection("files").doc(fileId).delete()

    console.log(`File metadata deleted from Firestore: ${fileId}`)

    return NextResponse.json({
      success: true,
      message: "File deleted successfully",
    })
  } catch (error) {
    console.error("Delete error:", error)
    return NextResponse.json(
      {
        error: "Failed to delete file",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const fileId = params.id

    // Get file document from Firestore
    const fileDoc = await firestore.collection("files").doc(fileId).get()

    if (!fileDoc.exists) {
      return NextResponse.json({ error: "File not found" }, { status: 404 })
    }

    const fileData = fileDoc.data()

    // Generate signed URL for download
    const bucket = storage.bucket(BUCKET_NAME)
    const file = bucket.file(fileData?.fileName || fileId)

    const [downloadUrl] = await file.getSignedUrl({
      action: "read",
      expires: Date.now() + 60 * 60 * 1000, // 1 hour
    })

    return NextResponse.json({
      success: true,
      file: {
        id: fileDoc.id,
        ...fileData,
        createdAt: fileData?.createdAt?.toDate?.()?.toISOString() || fileData?.createdAt,
        downloadUrl,
        previewUrl: fileData?.fileType === "image" ? downloadUrl : fileData?.publicUrl,
      },
    })
  } catch (error) {
    console.error("Error fetching file:", error)
    return NextResponse.json(
      {
        error: "Failed to fetch file",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

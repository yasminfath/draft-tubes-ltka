import { type NextRequest, NextResponse } from "next/server"
import { Firestore } from "@google-cloud/firestore"

// Initialize Firestore with the correct database ID
const firestore = new Firestore({
  projectId: process.env.GOOGLE_CLOUD_PROJECT_ID,
  keyFilename: process.env.GOOGLE_CLOUD_KEY_FILE,
  databaseId: process.env.FIRESTORE_DATABASE_ID || "dbtubesltka2425",
})

export async function GET(request: NextRequest, { params }: { params: { fileName: string } }) {
  try {
    const fileName = params.fileName

    console.log(`Fetching metadata for fileName: ${fileName}`)

    // Query media_metadata collection by fileName
    const metadataQuery = await firestore.collection("media_metadata").where("fileName", "==", fileName).limit(1).get()

    if (metadataQuery.empty) {
      console.log(`No metadata found for fileName: ${fileName}`)
      return NextResponse.json({
        success: false,
        error: "Metadata not found",
        metadata: null,
      })
    }

    const metadataDoc = metadataQuery.docs[0]
    const metadata = metadataDoc.data()

    // Convert Firestore timestamps to ISO strings
    const processedMetadata = processFirestoreData(metadata)

    console.log(`Found metadata for fileName: ${fileName}`)

    return NextResponse.json({
      success: true,
      metadata: {
        id: metadataDoc.id,
        ...processedMetadata,
      },
    })
  } catch (error) {
    console.error("Error fetching metadata:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to fetch metadata",
        details: error instanceof Error ? error.message : "Unknown error",
        metadata: null,
      },
      { status: 500 },
    )
  }
}

// Helper function to process Firestore data
function processFirestoreData(data: any): any {
  const processed: any = {}

  for (const [key, value] of Object.entries(data)) {
    if (value && typeof value === "object" && "toDate" in value) {
      // Convert Firestore Timestamp to ISO string
      processed[key] = value.toDate().toISOString()
    } else if (Array.isArray(value)) {
      // Process arrays recursively
      processed[key] = value.map((item) => (typeof item === "object" ? processFirestoreData(item) : item))
    } else if (value && typeof value === "object") {
      // Process nested objects recursively
      processed[key] = processFirestoreData(value)
    } else {
      processed[key] = value
    }
  }

  return processed
}

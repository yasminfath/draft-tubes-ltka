#!/bin/bash

# Minimal setup script for GCP Media Library (No billing required)
set -e

PROJECT_ID=${1:-"your-project-id"}
BUCKET_NAME=${2:-"media-library-uploads"}
REGION=${3:-"us-central1"}

echo "Setting up GCP Media Library (Minimal) for project: $PROJECT_ID"

# Set project
gcloud config set project $PROJECT_ID

# Enable only required APIs (free tier)
echo "Enabling required APIs..."
gcloud services enable storage.googleapis.com

# Create GCS bucket
echo "Creating GCS bucket: $BUCKET_NAME"
gsutil mb -p $PROJECT_ID -c STANDARD -l $REGION gs://$BUCKET_NAME

# Set bucket permissions (make it publicly readable)
echo "Setting bucket permissions..."
gsutil iam ch allUsers:objectViewer gs://$BUCKET_NAME

# Enable CORS for the bucket
echo "Setting CORS policy..."
cat > cors.json << EOF
[
  {
    "origin": ["*"],
    "method": ["GET", "HEAD", "PUT", "POST", "DELETE"],
    "responseHeader": ["*"],
    "maxAgeSeconds": 3600
  }
]
EOF

gsutil cors set cors.json gs://$BUCKET_NAME
rm cors.json

# Create service account (minimal permissions)
echo "Creating service account..."
gcloud iam service-accounts create media-library-minimal \
    --display-name="Media Library Minimal Service Account"

# Grant minimal permissions to service account
echo "Granting minimal permissions..."
gcloud projects add-iam-policy-binding $PROJECT_ID \
    --member="serviceAccount:media-library-minimal@$PROJECT_ID.iam.gserviceaccount.com" \
    --role="roles/storage.objectAdmin"

# Create and download service account key
echo "Creating service account key..."
gcloud iam service-accounts keys create ./service-account-key.json \
    --iam-account=media-library-minimal@$PROJECT_ID.iam.gserviceaccount.com

echo "Minimal setup complete!"
echo "Bucket name: $BUCKET_NAME"
echo "Service account key saved to: ./service-account-key.json"
echo ""
echo "Update your .env.local file with:"
echo "GOOGLE_CLOUD_PROJECT_ID=$PROJECT_ID"
echo "GOOGLE_CLOUD_KEY_FILE=./service-account-key.json"
echo "GCS_BUCKET_NAME=$BUCKET_NAME"
echo ""
echo "Note: This setup uses minimal APIs and doesn't require billing!"

import type { CloudFunction } from "@google-cloud/functions-framework"
import { Storage } from "@google-cloud/storage"
import { Firestore } from "@google-cloud/firestore"
import { PubSub } from "@google-cloud/pubsub"

const storage = new Storage()
const firestore = new Firestore()
const pubsub = new PubSub()

interface FileMetadata {
  id: string
  name: string
  bucket: string
  size: number
  contentType: string
  timeCreated: string
  generation: string
  fileType: "image" | "video" | "audio" | "unknown"
  status: "uploaded" | "processing" | "completed" | "error"
  aiAnalysis?: {
    tags: string[]
    transcript?: string
    objects?: string[]
    scenes?: string[]
  }
  versions: string[]
  uploadedBy: string
  createdAt: Date
  updatedAt: Date
}

export const processUpload: CloudFunction = async (data, context) => {
  try {
    const { bucket, name, generation, timeCreated, size, contentType } = data

    console.log(`Processing upload: ${name} in bucket ${bucket}`)

    // Determine file type
    const fileType = getFileType(contentType)

    // Create initial metadata document
    const fileId = `${bucket}_${name}_${generation}`
    const metadata: FileMetadata = {
      id: fileId,
      name,
      bucket,
      size: Number.parseInt(size),
      contentType,
      timeCreated,
      generation,
      fileType,
      status: "uploaded",
      versions: [generation],
      uploadedBy: context.auth?.uid || "anonymous",
      createdAt: new Date(),
      updatedAt: new Date(),
    }

    // Store initial metadata
    await firestore.collection("files").doc(fileId).set(metadata)

    // Enable versioning on the bucket if not already enabled
    await enableVersioning(bucket)

    // Set lifecycle policy if not already set
    await setLifecyclePolicy(bucket)

    // Trigger AI analysis
    if (fileType !== "unknown") {
      await triggerAIAnalysis(bucket, name, fileType, fileId)
    }

    console.log(`Successfully processed upload: ${fileId}`)
  } catch (error) {
    console.error("Error processing upload:", error)
    throw error
  }
}

function getFileType(contentType: string): "image" | "video" | "audio" | "unknown" {
  if (contentType.startsWith("image/")) return "image"
  if (contentType.startsWith("video/")) return "video"
  if (contentType.startsWith("audio/")) return "audio"
  return "unknown"
}

async function enableVersioning(bucketName: string): Promise<void> {
  try {
    const bucket = storage.bucket(bucketName)
    const [metadata] = await bucket.getMetadata()

    if (!metadata.versioning?.enabled) {
      await bucket.setMetadata({
        versioning: { enabled: true },
      })
      console.log(`Enabled versioning for bucket: ${bucketName}`)
    }
  } catch (error) {
    console.error("Error enabling versioning:", error)
  }
}

async function setLifecyclePolicy(bucketName: string): Promise<void> {
  try {
    const bucket = storage.bucket(bucketName)

    const lifecycleRule = {
      lifecycle: {
        rule: [
          {
            action: { type: "SetStorageClass", storageClass: "NEARLINE" },
            condition: { age: 30 },
          },
          {
            action: { type: "SetStorageClass", storageClass: "COLDLINE" },
            condition: { age: 90 },
          },
          {
            action: { type: "Delete" },
            condition: { age: 2555 }, // 7 years
          },
        ],
      },
    }

    await bucket.setMetadata(lifecycleRule)
    console.log(`Set lifecycle policy for bucket: ${bucketName}`)
  } catch (error) {
    console.error("Error setting lifecycle policy:", error)
  }
}

async function triggerAIAnalysis(bucket: string, fileName: string, fileType: string, fileId: string): Promise<void> {
  const message = {
    bucket,
    fileName,
    fileType,
    fileId,
  }

  await pubsub.topic("ai-analysis").publishMessage({
    data: Buffer.from(JSON.stringify(message)),
  })

  console.log(`Triggered AI analysis for: ${fileId}`)
}

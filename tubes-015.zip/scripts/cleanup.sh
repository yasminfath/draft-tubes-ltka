#!/bin/bash

# Cleanup Script
# Removes all resources created by the setup

set -e

echo "🗑️ Archivion Media Library Cleanup"
echo "=================================="

# Check if deployment config exists
if [ ! -f "deployment-config.json" ]; then
    echo "❌ deployment-config.json not found. Nothing to clean up."
    exit 1
fi

# Read configuration
PROJECT_ID=$(jq -r '.projectId' deployment-config.json)
REGION=$(jq -r '.region' deployment-config.json)
BUCKET_NAME=$(jq -r '.bucketName' deployment-config.json)
DATABASE_ID=$(jq -r '.databaseId' deployment-config.json)
SERVICE_ACCOUNT_EMAIL=$(jq -r '.serviceAccountEmail' deployment-config.json)
SERVICE_NAME="archivion-media-library"

echo "⚠️  This will delete:"
echo "  - Cloud Run service: $SERVICE_NAME"
echo "  - Storage bucket: $BUCKET_NAME (and all files)"
echo "  - Firestore database: $DATABASE_ID"
echo "  - Service account: $SERVICE_ACCOUNT_EMAIL"
echo ""

read -p "Are you sure you want to delete everything? (type 'DELETE' to confirm): " CONFIRM
if [ "$CONFIRM" != "DELETE" ]; then
    echo "❌ Cleanup cancelled"
    exit 1
fi

# Set project
gcloud config set project $PROJECT_ID

echo ""
echo "🗑️ Starting cleanup..."

# Delete Cloud Run service
echo "🚀 Deleting Cloud Run service..."
if gcloud run services describe $SERVICE_NAME --region $REGION > /dev/null 2>&1; then
    gcloud run services delete $SERVICE_NAME --region $REGION --quiet
    echo "✅ Cloud Run service deleted"
else
    echo "ℹ️ Cloud Run service not found"
fi

# Delete storage bucket
echo "🪣 Deleting storage bucket..."
if gsutil ls -b gs://$BUCKET_NAME > /dev/null 2>&1; then
    gsutil -m rm -r gs://$BUCKET_NAME
    echo "✅ Storage bucket deleted"
else
    echo "ℹ️ Storage bucket not found"
fi

# Delete Firestore database
echo "🗄️ Deleting Firestore database..."
if gcloud firestore databases describe --database=$DATABASE_ID > /dev/null 2>&1; then
    gcloud firestore databases delete --database=$DATABASE_ID --quiet
    echo "✅ Firestore database deleted"
else
    echo "ℹ️ Firestore database not found"
fi

# Delete service account
echo "👤 Deleting service account..."
if gcloud iam service-accounts describe $SERVICE_ACCOUNT_EMAIL > /dev/null 2>&1; then
    gcloud iam service-accounts delete $SERVICE_ACCOUNT_EMAIL --quiet
    echo "✅ Service account deleted"
else
    echo "ℹ️ Service account not found"
fi

# Clean up local files
echo "📁 Cleaning up local files..."
rm -f deployment-config.json
rm -f service-account-key.json
rm -f .env.local
rm -f Dockerfile
rm -f .dockerignore

echo ""
echo "✅ Cleanup complete!"
echo "All Archivion resources have been removed."

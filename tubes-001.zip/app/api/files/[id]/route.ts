import { type NextRequest, NextResponse } from "next/server"
import { Firestore } from "@google-cloud/firestore"
import { Storage } from "@google-cloud/storage"
import { auth } from "firebase-admin"
import { initializeApp } from "@/lib/firebase-admin"

// Initialize Firebase Admin
initializeApp()

const firestore = new Firestore({
  projectId: process.env.GOOGLE_CLOUD_PROJECT_ID,
  keyFilename: process.env.GOOGLE_CLOUD_KEY_FILE,
})

const storage = new Storage({
  projectId: process.env.GOOGLE_CLOUD_PROJECT_ID,
  keyFilename: process.env.GOOGLE_CLOUD_KEY_FILE,
})

const BUCKET_NAME = process.env.GCS_BUCKET_NAME || "media-library-uploads"

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const fileId = params.id

    // Verify authentication
    const authHeader = request.headers.get("authorization")
    if (!authHeader?.startsWith("Bearer ")) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.split("Bearer ")[1]
    let userId

    try {
      const decodedToken = await auth().verifyIdToken(token)
      userId = decodedToken.uid
    } catch (error) {
      return NextResponse.json({ error: "Invalid token" }, { status: 401 })
    }

    // Get file document
    const fileRef = firestore.collection("files").doc(fileId)
    const fileDoc = await fileRef.get()

    if (!fileDoc.exists) {
      return NextResponse.json({ error: "File not found" }, { status: 404 })
    }

    const fileData = fileDoc.data()

    // Check if user owns the file
    if (fileData?.userId !== userId) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
    }

    // Delete file from storage
    if (fileData?.path) {
      const bucket = storage.bucket(BUCKET_NAME)
      const file = bucket.file(fileData.path)
      await file.delete()
    }

    // Delete file document
    await fileRef.delete()

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Delete file error:", error)
    return NextResponse.json({ error: "Failed to delete file" }, { status: 500 })
  }
}

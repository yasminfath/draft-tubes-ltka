#!/bin/bash

# Make all scripts executable
chmod +x scripts/*.sh

echo "✅ All scripts are now executable!"
echo ""
echo "🚀 Quick Start:"
echo "1. ./scripts/setup-env.sh  - Setup environment and resources"
echo "2. ./scripts/deploy.sh     - Deploy to Cloud Run"
echo "3. ./scripts/status.sh     - Check status"
echo "4. ./scripts/logs.sh       - View logs"

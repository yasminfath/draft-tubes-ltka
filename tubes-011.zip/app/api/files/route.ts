import { type NextRequest, NextResponse } from "next/server"
import { Storage } from "@google-cloud/storage"
import { Firestore } from "@google-cloud/firestore"

// Initialize Google Cloud Storage
const storage = new Storage({
  projectId: process.env.GOOGLE_CLOUD_PROJECT_ID,
  keyFilename: process.env.GOOGLE_CLOUD_KEY_FILE,
})

// Initialize Firestore with custom database ID
const firestore = new Firestore({
  projectId: process.env.GOOGLE_CLOUD_PROJECT_ID,
  keyFilename: process.env.GOOGLE_CLOUD_KEY_FILE,
  databaseId: process.env.FIRESTORE_DATABASE_ID || "dbtubesltka2425", // Use environment variable or default
})

const BUCKET_NAME = process.env.GCS_BUCKET_NAME || "tubesltka2425"

// Helper function to get file type from content type
function getFileTypeFromContentType(contentType: string): "image" | "video" | "audio" | "unknown" {
  if (contentType.startsWith("image/")) return "image"
  if (contentType.startsWith("video/")) return "video"
  if (contentType.startsWith("audio/")) return "audio"
  return "unknown"
}

// Helper function to get thumbnail URL based on file type
function getThumbnailUrl(file: any, fileType: string): string {
  if (fileType === "image") {
    return file.publicUrl || file.mediaLink
  } else if (fileType === "video") {
    return "/video-thumbnail.jpg" // Default video thumbnail
  } else if (fileType === "audio") {
    return "/audio-thumbnail.jpg" // Default audio thumbnail
  }
  return "/placeholder.jpg" // Default placeholder
}

// Helper function to check if metadata exists in Firestore
async function checkMetadataExists(fileName: string): Promise<boolean> {
  try {
    const metadataQuery = await firestore.collection("media_metadata").where("fileName", "==", fileName).limit(1).get()

    if (!metadataQuery.empty) {
      return true
    }

    // Try alternative query with originalName
    const altQuery = await firestore.collection("media_metadata").where("originalName", "==", fileName).limit(1).get()
    return !altQuery.empty
  } catch (error) {
    console.error(`Error checking metadata for ${fileName}:`, error)
    return false
  }
}

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const fileType = searchParams.get("fileType")
    const searchText = searchParams.get("searchText")
    const limit = Number.parseInt(searchParams.get("limit") || "100")
    const offset = Number.parseInt(searchParams.get("offset") || "0")

    console.log("Fetching files with params:", { fileType, searchText, limit, offset })

    // Get files from bucket
    const [files] = await storage.bucket(BUCKET_NAME).getFiles()

    console.log(`Found ${files.length} files in bucket ${BUCKET_NAME}`)

    // Process files and get metadata
    let processedFiles = await Promise.all(
      files.map(async (file) => {
        try {
          const [metadata] = await file.getMetadata()

          // Extract original name from metadata if available
          const originalName = metadata.metadata?.originalName || file.name

          // Determine file type
          const contentType = metadata.contentType || ""
          const fileTypeFromContent = getFileTypeFromContentType(contentType)

          // Check if metadata exists in Firestore
          const hasMetadata = await checkMetadataExists(file.name)

          // Determine status based on metadata availability
          let status = "uploaded"
          if (hasMetadata) {
            status = "completed"
          } else {
            // Check file age - if older than 10 minutes and no metadata, might be processing
            const fileAge = Date.now() - new Date(metadata.timeCreated).getTime()
            const tenMinutes = 10 * 60 * 1000

            if (fileAge > tenMinutes) {
              status = "processing" // Still processing after 10 minutes
            } else {
              status = "uploaded" // Recently uploaded, processing expected
            }
          }

          // Generate signed URL for download
          const [downloadUrl] = await file.getSignedUrl({
            action: "read",
            expires: Date.now() + 24 * 60 * 60 * 1000, // 24 hours
          })

          // Get thumbnail URL based on file type
          const previewUrl = getThumbnailUrl(file, fileTypeFromContent)

          return {
            id: file.name,
            name: originalName,
            fileName: file.name,
            fileType: fileTypeFromContent,
            size: Number.parseInt(metadata.size),
            contentType: metadata.contentType,
            status: status, // Dynamic status based on metadata availability
            createdAt: metadata.timeCreated,
            downloadUrl: downloadUrl,
            previewUrl: previewUrl,
            publicUrl: `https://storage.googleapis.com/${BUCKET_NAME}/${file.name}`,
            hasMetadata: hasMetadata, // Add flag for frontend
          }
        } catch (error) {
          console.error(`Error processing file ${file.name}:`, error)
          return null
        }
      }),
    )

    // Filter out null values (failed processing)
    processedFiles = processedFiles.filter(Boolean)

    // Apply file type filter
    if (fileType && fileType !== "all") {
      processedFiles = processedFiles.filter((file) => file.fileType === fileType)
    }

    // Apply search filter if provided
    if (searchText) {
      const searchLower = searchText.toLowerCase()

      // Get metadata for search
      const metadataSnapshot = await firestore.collection("media_metadata").get()
      const metadataMap = new Map()

      metadataSnapshot.forEach((doc) => {
        const data = doc.data()
        if (data.fileName) {
          metadataMap.set(data.fileName, data)
        }
      })

      // Filter files based on name or metadata
      processedFiles = processedFiles.filter((file) => {
        // Check filename
        if (file.name.toLowerCase().includes(searchLower)) {
          return true
        }

        // Check metadata only if it exists
        if (file.hasMetadata) {
          const metadata = metadataMap.get(file.fileName)
          if (metadata) {
            // Check tags
            if (metadata.tags && Array.isArray(metadata.tags)) {
              if (metadata.tags.some((tag: string) => tag.toLowerCase().includes(searchLower))) {
                return true
              }
            }

            // Check object_tags
            if (metadata.object_tags && Array.isArray(metadata.object_tags)) {
              if (metadata.object_tags.some((tag: string) => tag.toLowerCase().includes(searchLower))) {
                return true
              }
            }

            // Check topics
            if (metadata.topics && Array.isArray(metadata.topics)) {
              if (metadata.topics.some((topic: string) => topic.toLowerCase().includes(searchLower))) {
                return true
              }
            }

            // Check transcription
            if (metadata.transcription && metadata.transcription.toLowerCase().includes(searchLower)) {
              return true
            }
          }
        }

        return false
      })
    }

    // Apply pagination
    const paginatedFiles = processedFiles.slice(offset, offset + limit)

    return NextResponse.json({
      success: true,
      files: paginatedFiles,
      total: processedFiles.length,
      limit,
      offset,
    })
  } catch (error) {
    console.error("Error fetching files:", error)
    return NextResponse.json(
      {
        error: "Failed to fetch files",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

"use client"
import ProtectedRoute from "@/components/protected-route"
import MediaLibrary from "@/components/media-library"

export default function Home() {
  return (
    <ProtectedRoute>
      <MediaLibrary />
    </ProtectedRoute>
  )
}

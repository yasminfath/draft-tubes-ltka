import { type NextRequest, NextResponse } from "next/server"
import { Storage } from "@google-cloud/storage"
import { Firestore } from "@google-cloud/firestore"

// Initialize Google Cloud Storage
const storage = new Storage({
  projectId: process.env.GOOGLE_CLOUD_PROJECT_ID,
  keyFilename: process.env.GOOGLE_CLOUD_KEY_FILE,
})

// Initialize Firestore
const firestore = new Firestore({
  projectId: process.env.GOOGLE_CLOUD_PROJECT_ID,
  keyFilename: process.env.GOOGLE_CLOUD_KEY_FILE,
  databaseId: process.env.FIRESTORE_DATABASE_ID || "dbtubesltka2425", // Add database ID
})

const BUCKET_NAME = process.env.GCS_BUCKET_NAME || "media-library-uploads"

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const fileType = searchParams.get("fileType")
    const searchText = searchParams.get("searchText")
    const limit = Number.parseInt(searchParams.get("limit") || "20")
    const offset = Number.parseInt(searchParams.get("offset") || "0")

    console.log("Fetching files with params:", { fileType, searchText, limit, offset })

    // Query Firestore for file metadata
    let query = firestore.collection("files")

    // Apply file type filter
    if (fileType && fileType !== "all") {
      query = query.where("fileType", "==", fileType)
    }

    // Execute query with pagination
    const snapshot = await query.orderBy("createdAt", "desc").limit(limit).offset(offset).get()

    let files = snapshot.docs.map((doc) => {
      const data = doc.data()
      return {
        id: doc.id,
        name: data.name,
        fileName: data.fileName,
        fileType: data.fileType,
        size: data.size,
        contentType: data.contentType,
        status: data.status,
        createdAt: data.createdAt?.toDate?.()?.toISOString() || data.createdAt,
        publicUrl: data.publicUrl,
        gcsPath: data.gcsPath,
        aiAnalysis: data.aiAnalysis || null,
      }
    })

    // Apply text search filter (client-side for now)
    if (searchText) {
      const searchLower = searchText.toLowerCase()
      files = files.filter(
        (file) =>
          file.name.toLowerCase().includes(searchLower) ||
          file.aiAnalysis?.tags?.some((tag: string) => tag.toLowerCase().includes(searchLower)) ||
          file.aiAnalysis?.transcript?.toLowerCase().includes(searchLower) ||
          file.aiAnalysis?.extractedText?.toLowerCase().includes(searchLower),
      )
    }

    // Generate signed URLs for secure access (optional, for private buckets)
    const filesWithUrls = await Promise.all(
      files.map(async (file) => {
        try {
          // For public buckets, use direct URL
          // For private buckets, generate signed URL
          const bucket = storage.bucket(BUCKET_NAME)
          const fileRef = bucket.file(file.fileName)

          // Check if file exists in bucket
          const [exists] = await fileRef.exists()
          if (!exists) {
            console.warn(`File not found in bucket: ${file.fileName}`)
            return {
              ...file,
              downloadUrl: null,
              previewUrl: null,
              status: "error",
            }
          }

          // Generate signed URL for download (valid for 1 hour)
          const [downloadUrl] = await fileRef.getSignedUrl({
            action: "read",
            expires: Date.now() + 60 * 60 * 1000, // 1 hour
          })

          return {
            ...file,
            downloadUrl,
            previewUrl: file.fileType === "image" ? downloadUrl : file.publicUrl,
          }
        } catch (error) {
          console.error(`Error generating URL for ${file.fileName}:`, error)
          return {
            ...file,
            downloadUrl: file.publicUrl,
            previewUrl: file.publicUrl,
          }
        }
      }),
    )

    console.log(`Retrieved ${filesWithUrls.length} files`)

    return NextResponse.json({
      success: true,
      files: filesWithUrls,
      total: filesWithUrls.length,
      limit,
      offset,
    })
  } catch (error) {
    console.error("Error fetching files:", error)
    return NextResponse.json(
      {
        error: "Failed to fetch files",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

import { type NextRequest, NextResponse } from "next/server"
import { GoogleAuth } from "google-auth-library"

const BUCKET_NAME = process.env.GCS_BUCKET_NAME || "media-library-uploads"

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const fileId = params.id

    console.log(`Deleting file: ${fileId}`)

    const auth = new GoogleAuth({
      keyFilename: process.env.GOOGLE_CLOUD_KEY_FILE,
      scopes: ["https://www.googleapis.com/auth/cloud-platform"],
    })

    const client = await auth.getClient()
    const accessToken = await client.getAccessToken()

    if (!accessToken.token) {
      throw new Error("Failed to get access token")
    }

    // Delete file using Storage JSON API
    const response = await fetch(
      `https://storage.googleapis.com/storage/v1/b/${BUCKET_NAME}/o/${encodeURIComponent(fileId)}`,
      {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${accessToken.token}`,
        },
      },
    )

    if (!response.ok && response.status !== 404) {
      throw new Error(`Failed to delete file: ${response.statusText}`)
    }

    console.log(`File deleted successfully: ${fileId}`)

    return NextResponse.json({
      success: true,
      message: "File deleted successfully",
    })
  } catch (error) {
    console.error("Delete error:", error)
    return NextResponse.json(
      {
        error: "Failed to delete file",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const fileId = params.id

    const auth = new GoogleAuth({
      keyFilename: process.env.GOOGLE_CLOUD_KEY_FILE,
      scopes: ["https://www.googleapis.com/auth/cloud-platform"],
    })

    const client = await auth.getClient()
    const accessToken = await client.getAccessToken()

    if (!accessToken.token) {
      throw new Error("Failed to get access token")
    }

    // Get file metadata using Storage JSON API
    const response = await fetch(
      `https://storage.googleapis.com/storage/v1/b/${BUCKET_NAME}/o/${encodeURIComponent(fileId)}`,
      {
        headers: {
          Authorization: `Bearer ${accessToken.token}`,
        },
      },
    )

    if (!response.ok) {
      if (response.status === 404) {
        return NextResponse.json({ error: "File not found" }, { status: 404 })
      }
      throw new Error(`Failed to get file: ${response.statusText}`)
    }

    const fileData = await response.json()

    return NextResponse.json({
      success: true,
      file: {
        id: fileData.name,
        name: fileData.name.split("-").slice(1).join("-"),
        fileName: fileData.name,
        fileType: getFileType(fileData.contentType || ""),
        size: Number.parseInt(fileData.size || "0"),
        contentType: fileData.contentType,
        status: "completed",
        createdAt: fileData.timeCreated,
        downloadUrl: `https://storage.googleapis.com/${BUCKET_NAME}/${fileData.name}`,
        previewUrl: `https://storage.googleapis.com/${BUCKET_NAME}/${fileData.name}`,
      },
    })
  } catch (error) {
    console.error("Error fetching file:", error)
    return NextResponse.json(
      {
        error: "Failed to fetch file",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

function getFileType(contentType: string): "image" | "video" | "audio" | "unknown" {
  if (contentType.startsWith("image/")) return "image"
  if (contentType.startsWith("video/")) return "video"
  if (contentType.startsWith("audio/")) return "audio"
  return "unknown"
}

#!/bin/bash

# Setup Environment Variables Script
# Run this first to configure your environment

set -e

echo "🚀 Setting up Archivion Media Library Environment"
echo "================================================"

# Get current project ID
PROJECT_ID=$(gcloud config get-value project)
if [ -z "$PROJECT_ID" ]; then
    echo "❌ No project selected. Please run: gcloud config set project YOUR_PROJECT_ID"
    exit 1
fi

echo "📋 Current Project: $PROJECT_ID"

# Set default values (you can modify these)
DEFAULT_REGION="us-central1"
DEFAULT_BUCKET_NAME="${PROJECT_ID}-media-storage"
DEFAULT_DB_ID="media-metadata-db"

# Get user input or use defaults
read -p "🌍 Enter region [$DEFAULT_REGION]: " REGION
REGION=${REGION:-$DEFAULT_REGION}

read -p "🪣 Enter bucket name [$DEFAULT_BUCKET_NAME]: " BUCKET_NAME
BUCKET_NAME=${BUCKET_NAME:-$DEFAULT_BUCKET_NAME}

read -p "🗄️ Enter Firestore database ID [$DEFAULT_DB_ID]: " DB_ID
DB_ID=${DB_ID:-$DEFAULT_DB_ID}

echo ""
echo "🔧 Configuration:"
echo "  Project ID: $PROJECT_ID"
echo "  Region: $REGION"
echo "  Bucket: $BUCKET_NAME"
echo "  Database: $DB_ID"
echo ""

read -p "Continue with this configuration? (y/N): " CONFIRM
if [[ ! $CONFIRM =~ ^[Yy]$ ]]; then
    echo "❌ Setup cancelled"
    exit 1
fi

echo ""
echo "🔨 Setting up services..."

# Enable required APIs
echo "📡 Enabling APIs..."
gcloud services enable cloudbuild.googleapis.com
gcloud services enable run.googleapis.com
gcloud services enable storage.googleapis.com
gcloud services enable firestore.googleapis.com

# Create storage bucket
echo "🪣 Creating storage bucket..."
if ! gsutil ls -b gs://$BUCKET_NAME > /dev/null 2>&1; then
    gsutil mb -l $REGION gs://$BUCKET_NAME
    echo "✅ Bucket created: gs://$BUCKET_NAME"
else
    echo "ℹ️ Bucket already exists: gs://$BUCKET_NAME"
fi

# Set bucket permissions for public read (optional)
echo "🔐 Setting bucket permissions..."
gsutil iam ch allUsers:objectViewer gs://$BUCKET_NAME

# Create Firestore database
echo "🗄️ Creating Firestore database..."
if ! gcloud firestore databases describe --database=$DB_ID > /dev/null 2>&1; then
    gcloud firestore databases create --database=$DB_ID --location=$REGION --type=firestore-native
    echo "✅ Firestore database created: $DB_ID"
else
    echo "ℹ️ Firestore database already exists: $DB_ID"
fi

# Create service account for the application
SERVICE_ACCOUNT_NAME="archivion-service"
SERVICE_ACCOUNT_EMAIL="${SERVICE_ACCOUNT_NAME}@${PROJECT_ID}.iam.gserviceaccount.com"

echo "👤 Creating service account..."
if ! gcloud iam service-accounts describe $SERVICE_ACCOUNT_EMAIL > /dev/null 2>&1; then
    gcloud iam service-accounts create $SERVICE_ACCOUNT_NAME \
        --display-name="Archivion Media Library Service Account"
    echo "✅ Service account created: $SERVICE_ACCOUNT_EMAIL"
else
    echo "ℹ️ Service account already exists: $SERVICE_ACCOUNT_EMAIL"
fi

# Grant necessary permissions
echo "🔑 Granting permissions..."
gcloud projects add-iam-policy-binding $PROJECT_ID \
    --member="serviceAccount:$SERVICE_ACCOUNT_EMAIL" \
    --role="roles/storage.admin"

gcloud projects add-iam-policy-binding $PROJECT_ID \
    --member="serviceAccount:$SERVICE_ACCOUNT_EMAIL" \
    --role="roles/datastore.user"

# Create and download service account key
KEY_FILE="service-account-key.json"
echo "🔐 Creating service account key..."
gcloud iam service-accounts keys create $KEY_FILE \
    --iam-account=$SERVICE_ACCOUNT_EMAIL

# Create .env file
echo "📝 Creating environment configuration..."
cat > .env.local << EOF
# Archivion Media Library Configuration
GOOGLE_CLOUD_PROJECT_ID=$PROJECT_ID
GOOGLE_CLOUD_KEY_FILE=./$KEY_FILE
GCS_BUCKET_NAME=$BUCKET_NAME
FIRESTORE_DATABASE_ID=$DB_ID

# Cloud Run will automatically provide these
# SEARCH_FUNCTION_URL=https://your-search-function-url
EOF

# Create deployment config
cat > deployment-config.json << EOF
{
  "projectId": "$PROJECT_ID",
  "region": "$REGION",
  "bucketName": "$BUCKET_NAME",
  "databaseId": "$DB_ID",
  "serviceAccountEmail": "$SERVICE_ACCOUNT_EMAIL",
  "keyFile": "$KEY_FILE"
}
EOF

echo ""
echo "✅ Environment setup complete!"
echo ""
echo "📋 Next steps:"
echo "1. Run: ./scripts/deploy.sh"
echo "2. Your app will be deployed to Cloud Run"
echo ""
echo "📁 Files created:"
echo "  - .env.local (environment variables)"
echo "  - $KEY_FILE (service account key)"
echo "  - deployment-config.json (deployment settings)"
echo ""
echo "⚠️  Keep $KEY_FILE secure and don't commit it to git!"

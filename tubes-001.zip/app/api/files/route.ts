import { type NextRequest, NextResponse } from "next/server"
import { Firestore } from "@google-cloud/firestore"
import { Storage } from "@google-cloud/storage"
import { auth } from "firebase-admin"
import { initializeApp } from "@/lib/firebase-admin"

// Initialize Firebase Admin
initializeApp()

const firestore = new Firestore({
  projectId: process.env.GOOGLE_CLOUD_PROJECT_ID,
  keyFilename: process.env.GOOGLE_CLOUD_KEY_FILE,
})

const storage = new Storage({
  projectId: process.env.GOOGLE_CLOUD_PROJECT_ID,
  keyFilename: process.env.GOOGLE_CLOUD_KEY_FILE,
})

const BUCKET_NAME = process.env.GCS_BUCKET_NAME || "media-library-uploads"
const CDN_DOMAIN = process.env.CDN_DOMAIN || `https://storage.googleapis.com/${BUCKET_NAME}`

export async function GET(request: NextRequest) {
  try {
    // Verify authentication
    const authHeader = request.headers.get("authorization")
    if (!authHeader?.startsWith("Bearer ")) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.split("Bearer ")[1]
    let userId

    try {
      const decodedToken = await auth().verifyIdToken(token)
      userId = decodedToken.uid
    } catch (error) {
      return NextResponse.json({ error: "Invalid token" }, { status: 401 })
    }

    const searchParams = request.nextUrl.searchParams
    const fileType = searchParams.get("fileType")
    const searchText = searchParams.get("searchText")
    const limit = Number(searchParams.get("limit") || "20")
    const offset = Number(searchParams.get("offset") || "0")

    // Query files for the authenticated user
    let query = firestore.collection("files").where("userId", "==", userId)

    if (fileType && fileType !== "all") {
      query = query.where("fileType", "==", fileType)
    }

    // Execute query
    const snapshot = await query.orderBy("createdAt", "desc").limit(limit).offset(offset).get()

    let files = snapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    }))

    // Client-side filtering for text search
    if (searchText) {
      const searchLower = searchText.toLowerCase()
      files = files.filter(
        (file) =>
          file.name.toLowerCase().includes(searchLower) ||
          file.aiAnalysis?.transcript?.toLowerCase().includes(searchLower) ||
          file.aiAnalysis?.extractedText?.toLowerCase().includes(searchLower) ||
          file.aiAnalysis?.tags?.some((tag: string) => tag.toLowerCase().includes(searchLower)),
      )
    }

    // Generate CDN URLs for file access
    const filesWithUrls = files.map((file) => {
      const cdnUrl = `${CDN_DOMAIN}/${file.path}`

      return {
        ...file,
        cdnUrl,
      }
    })

    return NextResponse.json({
      files: filesWithUrls,
      total: files.length,
      limit,
      offset,
    })
  } catch (error) {
    console.error("Files API error:", error)
    return NextResponse.json({ error: "Failed to retrieve files" }, { status: 500 })
  }
}

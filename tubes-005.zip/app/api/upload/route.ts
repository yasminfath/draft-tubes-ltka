import { type NextRequest, NextResponse } from "next/server"
import { Storage } from "@google-cloud/storage"
import { Firestore } from "@google-cloud/firestore"

// Initialize Google Cloud Storage
const storage = new Storage({
  projectId: process.env.GOOGLE_CLOUD_PROJECT_ID,
  keyFilename: process.env.GOOGLE_CLOUD_KEY_FILE, // Path to service account key
})

// Initialize Firestore
const firestore = new Firestore({
  projectId: process.env.GOOGLE_CLOUD_PROJECT_ID,
  keyFilename: process.env.GOOGLE_CLOUD_KEY_FILE,
})

const BUCKET_NAME = process.env.GCS_BUCKET_NAME || "media-library-uploads"

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const file = formData.get("file") as File

    if (!file) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 })
    }

    // Validate file size (100MB limit)
    const MAX_SIZE = 100 * 1024 * 1024 // 100MB
    if (file.size > MAX_SIZE) {
      return NextResponse.json(
        { error: `File size exceeds 100MB limit. Your file is ${(file.size / (1024 * 1024)).toFixed(2)}MB` },
        { status: 400 },
      )
    }

    // Generate unique filename
    const timestamp = Date.now()
    const sanitizedName = file.name.replace(/[^a-zA-Z0-9.-]/g, "_")
    const fileName = `${timestamp}-${sanitizedName}`

    console.log(`Uploading file: ${fileName} (${file.size} bytes)`)

    // Get bucket reference
    const bucket = storage.bucket(BUCKET_NAME)
    const fileRef = bucket.file(fileName)

    // Convert file to buffer
    const arrayBuffer = await file.arrayBuffer()
    const buffer = Buffer.from(arrayBuffer)

    // Upload file to GCS
    await fileRef.save(buffer, {
      metadata: {
        contentType: file.type,
        metadata: {
          originalName: file.name,
          uploadedAt: new Date().toISOString(),
        },
      },
    })

    console.log(`File uploaded successfully: ${fileName}`)

    // Get file metadata
    const [metadata] = await fileRef.getMetadata()

    // Determine file type
    const fileType = getFileType(file.type)

    // Create file document in Firestore
    const fileDoc = {
      id: fileName,
      name: file.name,
      fileName: fileName,
      bucket: BUCKET_NAME,
      size: file.size,
      contentType: file.type,
      fileType: fileType,
      status: "uploaded",
      createdAt: new Date(),
      updatedAt: new Date(),
      gcsPath: `gs://${BUCKET_NAME}/${fileName}`,
      publicUrl: `https://storage.googleapis.com/${BUCKET_NAME}/${fileName}`,
    }

    // Save to Firestore
    await firestore.collection("files").doc(fileName).set(fileDoc)

    console.log(`File metadata saved to Firestore: ${fileName}`)

    // Return success response
    return NextResponse.json({
      success: true,
      file: {
        id: fileName,
        name: file.name,
        fileName: fileName,
        size: file.size,
        contentType: file.type,
        fileType: fileType,
        status: "uploaded",
        createdAt: fileDoc.createdAt.toISOString(),
        publicUrl: fileDoc.publicUrl,
      },
    })
  } catch (error) {
    console.error("Upload error:", error)
    return NextResponse.json(
      {
        error: "Upload failed",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

// Helper function to determine file type
function getFileType(contentType: string): "image" | "video" | "audio" | "unknown" {
  if (contentType.startsWith("image/")) return "image"
  if (contentType.startsWith("video/")) return "video"
  if (contentType.startsWith("audio/")) return "audio"
  return "unknown"
}

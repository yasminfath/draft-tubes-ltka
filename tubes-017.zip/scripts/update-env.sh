#!/bin/bash

# Update Environment Variables Script
# Use this to update environment variables without full redeployment

set -e

echo "🔧 Updating Archivion Environment Variables"
echo "==========================================="

# Check if deployment config exists
if [ ! -f "deployment-config.json" ]; then
    echo "❌ deployment-config.json not found. Please run ./scripts/setup-env.sh first"
    exit 1
fi

# Read configuration
PROJECT_ID=$(jq -r '.projectId' deployment-config.json)
REGION=$(jq -r '.region' deployment-config.json)
SERVICE_NAME="archivion-media-library"

echo "📋 Current Project: $PROJECT_ID"
echo "🌍 Region: $REGION"
echo "🚀 Service: $SERVICE_NAME"
echo ""

# Set project
gcloud config set project $PROJECT_ID

# Show current environment variables
echo "📊 Current environment variables:"
gcloud run services describe $SERVICE_NAME --region $REGION --format="value(spec.template.spec.template.spec.containers[0].env[].name,spec.template.spec.template.spec.containers[0].env[].value)"

echo ""
echo "🔧 Available update options:"
echo "1. Add new environment variable"
echo "2. Update existing environment variable"
echo "3. Remove environment variable"
echo "4. View current variables"
echo ""

read -p "Choose option (1-4): " OPTION

case $OPTION in
    1)
        read -p "Enter variable name: " VAR_NAME
        read -p "Enter variable value: " VAR_VALUE
        gcloud run services update $SERVICE_NAME \
            --region $REGION \
            --set-env-vars "$VAR_NAME=$VAR_VALUE"
        echo "✅ Environment variable $VAR_NAME added"
        ;;
    2)
        read -p "Enter variable name to update: " VAR_NAME
        read -p "Enter new value: " VAR_VALUE
        gcloud run services update $SERVICE_NAME \
            --region $REGION \
            --set-env-vars "$VAR_NAME=$VAR_VALUE"
        echo "✅ Environment variable $VAR_NAME updated"
        ;;
    3)
        read -p "Enter variable name to remove: " VAR_NAME
        gcloud run services update $SERVICE_NAME \
            --region $REGION \
            --remove-env-vars "$VAR_NAME"
        echo "✅ Environment variable $VAR_NAME removed"
        ;;
    4)
        echo "📊 Current environment variables:"
        gcloud run services describe $SERVICE_NAME --region $REGION --format="table(spec.template.spec.template.spec.containers[0].env[].name,spec.template.spec.template.spec.containers[0].env[].value)"
        ;;
    *)
        echo "❌ Invalid option"
        exit 1
        ;;
esac

echo ""
echo "🌐 Service URL:"
gcloud run services describe $SERVICE_NAME --region $REGION --format 'value(status.url)'

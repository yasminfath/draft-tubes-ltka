import { type NextRequest, NextResponse } from "next/server"
import { Storage } from "@google-cloud/storage"
import { Firestore } from "@google-cloud/firestore"
import { auth } from "firebase-admin"
import { initializeApp } from "@/lib/firebase-admin"

// Initialize Firebase Admin
initializeApp()

const storage = new Storage({
  projectId: process.env.GOOGLE_CLOUD_PROJECT_ID,
  keyFilename: process.env.GOOGLE_CLOUD_KEY_FILE,
})

const firestore = new Firestore({
  projectId: process.env.GOOGLE_CLOUD_PROJECT_ID,
  keyFilename: process.env.GOOGLE_CLOUD_KEY_FILE,
})

const BUCKET_NAME = process.env.GCS_BUCKET_NAME || "media-library-uploads"

export async function POST(request: NextRequest) {
  try {
    // Verify authentication
    const authHeader = request.headers.get("authorization")
    if (!authHeader?.startsWith("Bearer ")) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.split("Bearer ")[1]
    let userId

    try {
      const decodedToken = await auth().verifyIdToken(token)
      userId = decodedToken.uid
    } catch (error) {
      return NextResponse.json({ error: "Invalid token" }, { status: 401 })
    }

    const { fileName, contentType } = await request.json()

    if (!fileName || !contentType) {
      return NextResponse.json({ error: "fileName and contentType are required" }, { status: 400 })
    }

    // Generate unique filename with timestamp and user ID
    const timestamp = Date.now()
    const uniqueFileName = `${userId}/${timestamp}-${fileName}`

    // Generate signed upload URL
    const bucket = storage.bucket(BUCKET_NAME)
    const file = bucket.file(uniqueFileName)

    const [uploadUrl] = await file.getSignedUrl({
      version: "v4",
      action: "write",
      expires: Date.now() + 15 * 60 * 1000, // 15 minutes
      contentType,
    })

    // Create initial file record in Firestore
    const fileDoc = {
      name: fileName,
      path: uniqueFileName,
      contentType,
      size: 0, // Will be updated after upload
      userId,
      status: "uploaded",
      createdAt: new Date(),
      updatedAt: new Date(),
    }

    await firestore.collection("files").add(fileDoc)

    return NextResponse.json({
      uploadUrl,
      fileName: uniqueFileName,
    })
  } catch (error) {
    console.error("Upload URL generation failed:", error)
    return NextResponse.json({ error: "Failed to generate upload URL" }, { status: 500 })
  }
}

#!/bin/bash

# View Logs Script
# Quick access to Cloud Run logs

set -e

# Check if deployment config exists
if [ ! -f "deployment-config.json" ]; then
    echo "❌ deployment-config.json not found. Please run ./scripts/setup-env.sh first"
    exit 1
fi

# Read configuration
PROJECT_ID=$(jq -r '.projectId' deployment-config.json)
REGION=$(jq -r '.region' deployment-config.json)
SERVICE_NAME="archivion-media-library"

echo "📊 Viewing logs for Archivion Media Library"
echo "=========================================="
echo "Project: $PROJECT_ID"
echo "Service: $SERVICE_NAME"
echo "Region: $REGION"
echo ""
echo "Press Ctrl+C to stop following logs"
echo ""

# Set project
gcloud config set project $PROJECT_ID

# Follow logs
gcloud logs tail --follow \
    --filter="resource.type=cloud_run_revision AND resource.labels.service_name=$SERVICE_NAME" \
    --format="table(timestamp,severity,textPayload)"

"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Upload, Search, Download, Eye, Trash2, AlertCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

interface MediaFile {
  id: string
  name: string
  fileType: "image" | "video" | "audio"
  size: number
  createdAt: string
  status: "uploaded" | "processing" | "completed" | "error"
  aiAnalysis?: {
    tags: string[]
    transcript?: string
    extractedText?: string
    scenes?: string[]
  }
  downloadUrl?: string
  previewUrl?: string
}

const MAX_FILE_SIZE = 100 * 1024 * 1024 // 100MB

// Mock data for demonstration
const mockFiles: MediaFile[] = [
  {
    id: "1",
    name: "sunset-beach.jpg",
    fileType: "image",
    size: 2.5 * 1024 * 1024,
    createdAt: "2024-01-15T10:30:00Z",
    status: "completed",
    aiAnalysis: {
      tags: ["sunset", "beach", "ocean", "landscape", "golden hour"],
      extractedText: "Beach Resort Sign",
    },
    downloadUrl: "/placeholder.svg?height=400&width=600",
    previewUrl: "/placeholder.svg?height=400&width=600",
  },
  {
    id: "2",
    name: "presentation-video.mp4",
    fileType: "video",
    size: 45 * 1024 * 1024,
    createdAt: "2024-01-14T14:20:00Z",
    status: "completed",
    aiAnalysis: {
      tags: ["presentation", "business", "meeting", "slides"],
      transcript:
        "Welcome to our quarterly business review. Today we'll be discussing our performance metrics, key achievements, and strategic initiatives for the upcoming quarter. Our revenue has grown by 25% compared to last quarter...",
      scenes: ["title slide", "charts and graphs", "team discussion"],
    },
    downloadUrl: "#",
    previewUrl: "/placeholder.svg?height=300&width=500",
  },
  {
    id: "3",
    name: "podcast-episode-01.mp3",
    fileType: "audio",
    size: 15 * 1024 * 1024,
    createdAt: "2024-01-13T09:15:00Z",
    status: "completed",
    aiAnalysis: {
      tags: ["podcast", "interview", "technology", "startup"],
      transcript:
        "In today's episode, we're talking with Sarah Johnson, CEO of TechStart, about the future of artificial intelligence in small businesses. Sarah, thanks for joining us today. Can you tell us about your journey in the tech industry?",
    },
    downloadUrl: "#",
  },
  {
    id: "4",
    name: "product-demo.mov",
    fileType: "video",
    size: 78 * 1024 * 1024,
    createdAt: "2024-01-12T16:45:00Z",
    status: "processing",
    downloadUrl: "#",
  },
  {
    id: "5",
    name: "conference-notes.jpg",
    fileType: "image",
    size: 1.8 * 1024 * 1024,
    createdAt: "2024-01-11T11:30:00Z",
    status: "completed",
    aiAnalysis: {
      tags: ["notes", "handwriting", "conference", "agenda"],
      extractedText:
        "Conference Agenda\n1. Opening Keynote - 9:00 AM\n2. Panel Discussion - 10:30 AM\n3. Networking Break - 12:00 PM\n4. Workshop Sessions - 1:30 PM\n5. Closing Remarks - 4:00 PM",
    },
    downloadUrl: "/placeholder.svg?height=500&width=400",
    previewUrl: "/placeholder.svg?height=500&width=400",
  },
]

export default function MediaLibrary() {
  const [files, setFiles] = useState<MediaFile[]>(mockFiles)
  const [filteredFiles, setFilteredFiles] = useState<MediaFile[]>(mockFiles)
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedFileType, setSelectedFileType] = useState<string>("all")
  const [isUploading, setIsUploading] = useState(false)
  const [loading, setLoading] = useState(false)
  const [uploadError, setUploadError] = useState("")
  const [selectedFile, setSelectedFile] = useState<MediaFile | null>(null)
  const [showDetails, setShowDetails] = useState(false)

  useEffect(() => {
    filterFiles()
  }, [searchQuery, selectedFileType, files])

  const filterFiles = () => {
    let filtered = files

    // Filter by file type
    if (selectedFileType !== "all") {
      filtered = filtered.filter((file) => file.fileType === selectedFileType)
    }

    // Filter by search query
    if (searchQuery) {
      const searchLower = searchQuery.toLowerCase()
      filtered = filtered.filter(
        (file) =>
          file.name.toLowerCase().includes(searchLower) ||
          file.aiAnalysis?.tags?.some((tag) => tag.toLowerCase().includes(searchLower)) ||
          file.aiAnalysis?.transcript?.toLowerCase().includes(searchLower) ||
          file.aiAnalysis?.extractedText?.toLowerCase().includes(searchLower),
      )
    }

    setFilteredFiles(filtered)
  }

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    setUploadError("")

    // Check file size
    if (file.size > MAX_FILE_SIZE) {
      setUploadError(
        `File size exceeds the maximum limit of 100MB. Your file is ${(file.size / (1024 * 1024)).toFixed(2)}MB.`,
      )
      return
    }

    setIsUploading(true)

    try {
      // Simulate upload process
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // Create new file entry
      const newFile: MediaFile = {
        id: Date.now().toString(),
        name: file.name,
        fileType: getFileType(file.type),
        size: file.size,
        createdAt: new Date().toISOString(),
        status: "uploaded",
        downloadUrl: "#",
      }

      setFiles([newFile, ...files])

      // Simulate processing
      setTimeout(() => {
        setFiles((prevFiles) =>
          prevFiles.map((f) =>
            f.id === newFile.id
              ? {
                  ...f,
                  status: "processing",
                }
              : f,
          ),
        )
      }, 1000)

      // Simulate completion
      setTimeout(() => {
        setFiles((prevFiles) =>
          prevFiles.map((f) =>
            f.id === newFile.id
              ? {
                  ...f,
                  status: "completed",
                  aiAnalysis: {
                    tags: ["uploaded", "new", "file"],
                    transcript: file.type.startsWith("audio") ? "Processing audio transcript..." : undefined,
                  },
                }
              : f,
          ),
        )
      }, 5000)
    } catch (error) {
      console.error("Upload failed:", error)
      setUploadError("Failed to upload file. Please try again.")
    } finally {
      setIsUploading(false)
    }
  }

  const handleDeleteFile = (fileId: string) => {
    if (!confirm("Are you sure you want to delete this file?")) return

    setFiles(files.filter((file) => file.id !== fileId))
    if (selectedFile?.id === fileId) {
      setShowDetails(false)
      setSelectedFile(null)
    }
  }

  const viewFileDetails = (file: MediaFile) => {
    setSelectedFile(file)
    setShowDetails(true)
  }

  const getFileType = (contentType: string): "image" | "video" | "audio" => {
    if (contentType.startsWith("image/")) return "image"
    if (contentType.startsWith("video/")) return "video"
    if (contentType.startsWith("audio/")) return "audio"
    return "image" // fallback
  }

  const getFileIcon = (fileType: string) => {
    switch (fileType) {
      case "image":
        return "🖼️"
      case "video":
        return "🎥"
      case "audio":
        return "🎵"
      default:
        return "📄"
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-100 text-green-800"
      case "processing":
        return "bg-yellow-100 text-yellow-800"
      case "error":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const formatFileSize = (bytes: number) => {
    return (bytes / (1024 * 1024)).toFixed(2)
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">AI-Powered Media Library</h1>
        <p className="text-gray-600">Upload, analyze, and manage your media files with intelligent tagging</p>
      </div>

      <Tabs defaultValue="library" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="library">Media Library</TabsTrigger>
          <TabsTrigger value="upload">Upload Files</TabsTrigger>
        </TabsList>

        <TabsContent value="upload" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Upload className="h-5 w-5" />
                Upload Media Files
              </CardTitle>
            </CardHeader>
            <CardContent>
              {uploadError && (
                <Alert variant="destructive" className="mb-4">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{uploadError}</AlertDescription>
                </Alert>
              )}
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                <input
                  type="file"
                  accept="image/*,video/*,audio/*"
                  onChange={handleFileUpload}
                  disabled={isUploading}
                  className="hidden"
                  id="file-upload"
                />
                <label htmlFor="file-upload" className="cursor-pointer flex flex-col items-center gap-4">
                  <Upload className="h-12 w-12 text-gray-400" />
                  <div>
                    <p className="text-lg font-medium">{isUploading ? "Uploading..." : "Click to upload files"}</p>
                    <p className="text-sm text-gray-500">Supports images, videos, and audio files (max 100MB)</p>
                  </div>
                </label>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="library" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Search className="h-5 w-5" />
                Search & Filter
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-4">
                <div className="flex-1">
                  <Input
                    placeholder="Search by filename, tags, or transcript..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                <Select value={selectedFileType} onValueChange={setSelectedFileType}>
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="image">Images</SelectItem>
                    <SelectItem value="video">Videos</SelectItem>
                    <SelectItem value="audio">Audio</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {loading ? (
              <div className="col-span-full text-center py-8">
                <p>Loading files...</p>
              </div>
            ) : filteredFiles.length === 0 ? (
              <div className="col-span-full text-center py-8">
                <p className="text-gray-500">No files found. Upload some media to get started!</p>
              </div>
            ) : (
              filteredFiles.map((file) => (
                <Card key={file.id} className="overflow-hidden">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-2xl">{getFileIcon(file.fileType)}</span>
                        <div>
                          <CardTitle className="text-sm truncate max-w-40">{file.name}</CardTitle>
                          <p className="text-xs text-gray-500">{formatFileSize(file.size)} MB</p>
                        </div>
                      </div>
                      <Badge className={getStatusColor(file.status)}>{file.status}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {file.aiAnalysis?.tags && file.aiAnalysis.tags.length > 0 && (
                      <div>
                        <p className="text-xs font-medium text-gray-700 mb-1">AI Tags:</p>
                        <div className="flex flex-wrap gap-1">
                          {file.aiAnalysis.tags.slice(0, 3).map((tag, index) => (
                            <Badge key={index} variant="secondary" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                          {file.aiAnalysis.tags.length > 3 && (
                            <Badge variant="outline" className="text-xs">
                              +{file.aiAnalysis.tags.length - 3}
                            </Badge>
                          )}
                        </div>
                      </div>
                    )}

                    {file.aiAnalysis?.transcript && (
                      <div>
                        <p className="text-xs font-medium text-gray-700 mb-1">Transcript:</p>
                        <p className="text-xs text-gray-600 line-clamp-2">
                          {file.aiAnalysis.transcript.substring(0, 100)}...
                        </p>
                      </div>
                    )}

                    <div className="text-xs text-gray-500">Uploaded: {formatDate(file.createdAt)}</div>
                  </CardContent>
                  <CardFooter className="flex gap-2 pt-2">
                    {file.downloadUrl && (
                      <Button size="sm" variant="outline" asChild>
                        <a href={file.downloadUrl} download>
                          <Download className="h-3 w-3 mr-1" />
                          Download
                        </a>
                      </Button>
                    )}
                    <Button size="sm" variant="outline" onClick={() => viewFileDetails(file)}>
                      <Eye className="h-3 w-3 mr-1" />
                      Details
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="ml-auto text-red-600 hover:text-red-700"
                      onClick={() => handleDeleteFile(file.id)}
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </CardFooter>
                </Card>
              ))
            )}
          </div>
        </TabsContent>
      </Tabs>

      {/* File Details Dialog */}
      <Dialog open={showDetails} onOpenChange={setShowDetails}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {selectedFile && (
                <>
                  <span>{getFileIcon(selectedFile.fileType)}</span>
                  {selectedFile.name}
                </>
              )}
            </DialogTitle>
            <DialogDescription>
              {selectedFile && (
                <>
                  {selectedFile.fileType} • {formatFileSize(selectedFile.size)} MB • Uploaded{" "}
                  {formatDate(selectedFile.createdAt)}
                </>
              )}
            </DialogDescription>
          </DialogHeader>

          {selectedFile && (
            <div className="space-y-6">
              {/* Preview */}
              {selectedFile.fileType === "image" && selectedFile.previewUrl && (
                <div className="rounded-md overflow-hidden bg-gray-100 flex justify-center">
                  <img
                    src={selectedFile.previewUrl || "/placeholder.svg"}
                    alt={selectedFile.name}
                    className="max-w-full h-auto max-h-96 object-contain"
                  />
                </div>
              )}

              {selectedFile.fileType === "video" && selectedFile.previewUrl && (
                <div className="rounded-md overflow-hidden bg-gray-100 flex justify-center">
                  <div className="w-full max-w-2xl">
                    <div className="aspect-video bg-gray-200 rounded flex items-center justify-center">
                      <div className="text-center">
                        <div className="text-4xl mb-2">🎥</div>
                        <p className="text-sm text-gray-600">Video Preview</p>
                        <p className="text-xs text-gray-500">{selectedFile.name}</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {selectedFile.fileType === "audio" && (
                <div className="rounded-md overflow-hidden bg-gray-100 p-8 flex justify-center">
                  <div className="text-center">
                    <div className="text-4xl mb-2">🎵</div>
                    <p className="text-sm text-gray-600">Audio File</p>
                    <p className="text-xs text-gray-500">{selectedFile.name}</p>
                  </div>
                </div>
              )}

              {/* AI Analysis */}
              {selectedFile.status === "completed" && selectedFile.aiAnalysis && (
                <Accordion type="single" collapsible className="w-full">
                  {selectedFile.aiAnalysis.tags && selectedFile.aiAnalysis.tags.length > 0 && (
                    <AccordionItem value="tags">
                      <AccordionTrigger>AI Tags ({selectedFile.aiAnalysis.tags.length})</AccordionTrigger>
                      <AccordionContent>
                        <div className="flex flex-wrap gap-2">
                          {selectedFile.aiAnalysis.tags.map((tag, index) => (
                            <Badge key={index} variant="secondary">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  )}

                  {selectedFile.aiAnalysis.transcript && (
                    <AccordionItem value="transcript">
                      <AccordionTrigger>Transcript</AccordionTrigger>
                      <AccordionContent>
                        <div className="bg-gray-50 p-4 rounded-md max-h-60 overflow-y-auto">
                          <p className="whitespace-pre-line text-sm">{selectedFile.aiAnalysis.transcript}</p>
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  )}

                  {selectedFile.aiAnalysis.extractedText && (
                    <AccordionItem value="extractedText">
                      <AccordionTrigger>Extracted Text</AccordionTrigger>
                      <AccordionContent>
                        <div className="bg-gray-50 p-4 rounded-md max-h-60 overflow-y-auto">
                          <p className="whitespace-pre-line text-sm">{selectedFile.aiAnalysis.extractedText}</p>
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  )}

                  {selectedFile.aiAnalysis.scenes && selectedFile.aiAnalysis.scenes.length > 0 && (
                    <AccordionItem value="scenes">
                      <AccordionTrigger>Detected Scenes</AccordionTrigger>
                      <AccordionContent>
                        <div className="space-y-2">
                          {selectedFile.aiAnalysis.scenes.map((scene, index) => (
                            <div key={index} className="flex items-center gap-2">
                              <Badge variant="outline" className="text-xs">
                                Scene {index + 1}
                              </Badge>
                              <span className="text-sm">{scene}</span>
                            </div>
                          ))}
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  )}
                </Accordion>
              )}

              {selectedFile.status === "processing" && (
                <div className="text-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-gray-900 mx-auto mb-4"></div>
                  <p className="text-sm text-gray-600">AI analysis in progress...</p>
                </div>
              )}

              {selectedFile.status === "error" && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    There was an error processing this file. Please try uploading again.
                  </AlertDescription>
                </Alert>
              )}

              {/* Actions */}
              <div className="flex justify-end gap-2 pt-4 border-t">
                {selectedFile.downloadUrl && (
                  <Button variant="outline" asChild>
                    <a href={selectedFile.downloadUrl} download>
                      <Download className="h-4 w-4 mr-2" />
                      Download
                    </a>
                  </Button>
                )}
                <Button
                  variant="destructive"
                  onClick={() => {
                    handleDeleteFile(selectedFile.id)
                    setShowDetails(false)
                  }}
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

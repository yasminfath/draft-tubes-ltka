import { type NextRequest, NextResponse } from "next/server"

// Minimal Google Auth untuk signed URL (tidak butuh billing)
import { GoogleAuth } from "google-auth-library"

const BUCKET_NAME = process.env.GCS_BUCKET_NAME || "media-library-uploads"

export async function POST(request: NextRequest) {
  try {
    const { fileName, contentType, fileSize } = await request.json()

    if (!fileName || !contentType) {
      return NextResponse.json({ error: "fileName and contentType are required" }, { status: 400 })
    }

    // Validate file size (100MB limit)
    const MAX_SIZE = 100 * 1024 * 1024 // 100MB
    if (fileSize && fileSize > MAX_SIZE) {
      return NextResponse.json(
        { error: `File size exceeds 100MB limit. Your file is ${(fileSize / (1024 * 1024)).toFixed(2)}MB` },
        { status: 400 },
      )
    }

    // Generate unique filename
    const timestamp = Date.now()
    const sanitizedName = fileName.replace(/[^a-zA-Z0-9.-]/g, "_")
    const uniqueFileName = `${timestamp}-${sanitizedName}`

    console.log(`Generating signed URL for: ${uniqueFileName}`)

    // Generate signed URL using minimal auth
    const signedUrl = await generateSignedUploadUrl(uniqueFileName, contentType)

    return NextResponse.json({
      success: true,
      uploadUrl: signedUrl,
      fileName: uniqueFileName,
      bucketName: BUCKET_NAME,
    })
  } catch (error) {
    console.error("Signed URL generation failed:", error)
    return NextResponse.json(
      {
        error: "Failed to generate upload URL",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

async function generateSignedUploadUrl(fileName: string, contentType: string): Promise<string> {
  try {
    // Use Google Auth library (minimal, no billing required)
    const auth = new GoogleAuth({
      keyFilename: process.env.GOOGLE_CLOUD_KEY_FILE,
      scopes: ["https://www.googleapis.com/auth/cloud-platform"],
    })

    const client = await auth.getClient()
    const projectId = await auth.getProjectId()

    // Create signed URL manually using REST API
    const expiration = Math.floor(Date.now() / 1000) + 3600 // 1 hour from now

    // For simplicity, we'll use a direct approach
    // In production, you might want to use the Storage JSON API
    const url = `https://storage.googleapis.com/upload/storage/v1/b/${BUCKET_NAME}/o?uploadType=media&name=${encodeURIComponent(fileName)}`

    // Get access token
    const accessToken = await client.getAccessToken()

    if (!accessToken.token) {
      throw new Error("Failed to get access token")
    }

    // Return the upload URL with auth header info
    return JSON.stringify({
      url: url,
      headers: {
        Authorization: `Bearer ${accessToken.token}`,
        "Content-Type": contentType,
      },
    })
  } catch (error) {
    console.error("Error generating signed URL:", error)
    throw error
  }
}

#!/bin/bash

# Deploy script for GCP Media Library
set -e

PROJECT_ID=${1:-"your-project-id"}
REGION=${2:-"us-central1"}

echo "Deploying GCP Media Library to project: $PROJECT_ID"

# Set project
gcloud config set project $PROJECT_ID

# Build and package Cloud Functions
echo "Building Cloud Functions..."
cd functions/upload-processor
npm install && npm run build
zip -r ../upload-processor.zip . -x "node_modules/*" "src/*" "*.ts"
cd ../..

cd functions/ai-analyzer
npm install && npm run build
zip -r ../ai-analyzer.zip . -x "node_modules/*" "src/*" "*.ts"
cd ../..

cd functions/search-api
npm install && npm run build
zip -r ../search-api.zip . -x "node_modules/*" "src/*" "*.ts"
cd ../..

# Deploy infrastructure with Terraform
echo "Deploying infrastructure..."
cd terraform
terraform init
terraform plan -var="project_id=$PROJECT_ID" -var="region=$REGION"
terraform apply -var="project_id=$PROJECT_ID" -var="region=$REGION" -auto-approve
cd ..

# Deploy frontend to Cloud Run
echo "Deploying frontend..."
cd frontend
gcloud run deploy media-library-frontend \
  --source . \
  --platform managed \
  --region $REGION \
  --allow-unauthenticated \
  --set-env-vars="GOOGLE_CLOUD_PROJECT_ID=$PROJECT_ID,GCS_BUCKET_NAME=media-library-uploads-$PROJECT_ID"

echo "Deployment complete!"
echo "Frontend URL: $(gcloud run services describe media-library-frontend --region=$REGION --format='value(status.url)')"

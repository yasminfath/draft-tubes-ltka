import { type NextRequest, NextResponse } from "next/server"
import { Firestore } from "@google-cloud/firestore"
import { Storage } from "@google-cloud/storage"
import { ImageAnnotatorClient } from "@google-cloud/vision"
import { VideoIntelligenceServiceClient } from "@google-cloud/video-intelligence"
import { SpeechClient } from "@google-cloud/speech"
import { initializeApp } from "@/lib/firebase-admin"

// Initialize Firebase Admin
initializeApp()

const firestore = new Firestore({
  projectId: process.env.GOOGLE_CLOUD_PROJECT_ID,
  keyFilename: process.env.GOOGLE_CLOUD_KEY_FILE,
})

const storage = new Storage({
  projectId: process.env.GOOGLE_CLOUD_PROJECT_ID,
  keyFilename: process.env.GOOGLE_CLOUD_KEY_FILE,
})

const visionClient = new ImageAnnotatorClient({
  keyFilename: process.env.GOOGLE_CLOUD_KEY_FILE,
})

const videoClient = new VideoIntelligenceServiceClient({
  keyFilename: process.env.GOOGLE_CLOUD_KEY_FILE,
})

const speechClient = new SpeechClient({
  keyFilename: process.env.GOOGLE_CLOUD_KEY_FILE,
})

const BUCKET_NAME = process.env.GCS_BUCKET_NAME || "media-library-uploads"

export async function POST(request: NextRequest) {
  try {
    // This endpoint is triggered by Cloud Run when a file is uploaded
    // It should be secured with a service account or secret
    const { fileId } = await request.json()

    if (!fileId) {
      return NextResponse.json({ error: "fileId is required" }, { status: 400 })
    }

    // Get file document
    const fileRef = firestore.collection("files").doc(fileId)
    const fileDoc = await fileRef.get()

    if (!fileDoc.exists) {
      return NextResponse.json({ error: "File not found" }, { status: 404 })
    }

    const fileData = fileDoc.data()

    // Update status to processing
    await fileRef.update({
      status: "processing",
      updatedAt: new Date(),
    })

    // Determine file type
    const contentType = fileData?.contentType || ""
    const fileType = getFileType(contentType)

    // Process file with appropriate AI service
    let analysis = {}

    try {
      switch (fileType) {
        case "image":
          analysis = await analyzeImage(fileData?.path)
          break
        case "video":
          analysis = await analyzeVideo(fileData?.path)
          break
        case "audio":
          analysis = await analyzeAudio(fileData?.path)
          break
      }

      // Update file with analysis results
      await fileRef.update({
        fileType,
        aiAnalysis: analysis,
        status: "completed",
        updatedAt: new Date(),
      })

      return NextResponse.json({ success: true })
    } catch (error) {
      console.error("AI processing error:", error)

      // Update status to error
      await fileRef.update({
        status: "error",
        updatedAt: new Date(),
      })

      return NextResponse.json({ error: "AI processing failed" }, { status: 500 })
    }
  } catch (error) {
    console.error("Process API error:", error)
    return NextResponse.json({ error: "Failed to process file" }, { status: 500 })
  }
}

function getFileType(contentType: string): "image" | "video" | "audio" | "unknown" {
  if (contentType.startsWith("image/")) return "image"
  if (contentType.startsWith("video/")) return "video"
  if (contentType.startsWith("audio/")) return "audio"
  return "unknown"
}

async function analyzeImage(filePath: string) {
  const gcsUri = `gs://${BUCKET_NAME}/${filePath}`

  const [result] = await visionClient.annotateImage({
    image: { source: { imageUri: gcsUri } },
    features: [
      { type: "LABEL_DETECTION", maxResults: 10 },
      { type: "OBJECT_LOCALIZATION", maxResults: 10 },
      { type: "TEXT_DETECTION" },
      { type: "SAFE_SEARCH_DETECTION" },
    ],
  })

  const tags = result.labelAnnotations?.map((label) => label.description || "") || []
  const objects = result.localizedObjectAnnotations?.map((obj) => obj.name || "") || []
  const text = result.textAnnotations?.[0]?.description || ""

  return {
    tags: [...new Set([...tags, ...objects])], // Remove duplicates
    extractedText: text,
    safeSearch: result.safeSearchAnnotation,
  }
}

async function analyzeVideo(filePath: string) {
  const gcsUri = `gs://${BUCKET_NAME}/${filePath}`

  const [operation] = await videoClient.annotateVideo({
    inputUri: gcsUri,
    features: ["LABEL_DETECTION", "SHOT_CHANGE_DETECTION", "SPEECH_TRANSCRIPTION"],
    videoContext: {
      speechTranscriptionConfig: {
        languageCode: "en-US",
        enableAutomaticPunctuation: true,
      },
    },
  })

  const [result] = await operation.promise()

  const tags =
    result.annotationResults?.[0]?.segmentLabelAnnotations?.map((label) => label.entity?.description || "") || []

  const scenes =
    result.annotationResults?.[0]?.shotLabelAnnotations?.map((shot) => shot.entity?.description || "") || []

  const transcript =
    result.annotationResults?.[0]?.speechTranscriptions
      ?.map((transcription) => transcription.alternatives?.[0]?.transcript || "")
      .join(" ") || ""

  return {
    tags: [...new Set(tags)],
    scenes: [...new Set(scenes)],
    transcript,
  }
}

async function analyzeAudio(filePath: string) {
  const gcsUri = `gs://${BUCKET_NAME}/${filePath}`

  const [operation] = await speechClient.longRunningRecognize({
    config: {
      languageCode: "en-US",
      enableAutomaticPunctuation: true,
      enableWordTimeOffsets: true,
    },
    audio: { uri: gcsUri },
  })

  const [result] = await operation.promise()

  const transcript = result.results?.map((result) => result.alternatives?.[0]?.transcript || "").join(" ") || ""

  return {
    transcript,
    tags: extractKeywords(transcript),
  }
}

function extractKeywords(text: string) {
  // Simple keyword extraction - in production, you might use a more sophisticated approach
  const words = text.toLowerCase().split(/\s+/)
  const stopWords = new Set(["a", "an", "the", "and", "or", "but", "in", "on", "at", "to", "for", "with", "by", "of"])

  const filteredWords = words.filter((word) => word.length > 3 && !stopWords.has(word) && /^[a-z]+$/.test(word))

  // Count word frequency
  const wordCounts = filteredWords.reduce(
    (acc, word) => {
      acc[word] = (acc[word] || 0) + 1
      return acc
    },
    {} as Record<string, number>,
  )

  // Sort by frequency and take top 10
  return Object.entries(wordCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10)
    .map(([word]) => word)
}

import type { CloudFunction } from "@google-cloud/functions-framework"
import { Firestore } from "@google-cloud/firestore"
import { Storage } from "@google-cloud/storage"

const firestore = new Firestore()
const storage = new Storage()

interface SearchQuery {
  tags?: string[]
  fileType?: string
  dateRange?: {
    start: string
    end: string
  }
  searchText?: string
  limit?: number
  offset?: number
}

export const searchFiles: CloudFunction = async (req, res) => {
  try {
    // Enable CORS
    res.set("Access-Control-Allow-Origin", "*")
    res.set("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
    res.set("Access-Control-Allow-Headers", "Content-Type, Authorization")

    if (req.method === "OPTIONS") {
      res.status(200).send()
      return
    }

    const query: SearchQuery = req.method === "GET" ? req.query : req.body
    const { tags, fileType, dateRange, searchText, limit = 20, offset = 0 } = query

    let firestoreQuery = firestore.collection("files").where("status", "==", "completed")

    // Apply filters
    if (fileType) {
      firestoreQuery = firestoreQuery.where("fileType", "==", fileType)
    }

    if (dateRange) {
      firestoreQuery = firestoreQuery
        .where("createdAt", ">=", new Date(dateRange.start))
        .where("createdAt", "<=", new Date(dateRange.end))
    }

    // Execute query
    const snapshot = await firestoreQuery
      .orderBy("createdAt", "desc")
      .limit(Number.parseInt(limit.toString()))
      .offset(Number.parseInt(offset.toString()))
      .get()

    let results = snapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    }))

    // Client-side filtering for tags and text search
    if (tags && tags.length > 0) {
      results = results.filter((file) =>
        tags.some((tag) =>
          file.aiAnalysis?.tags?.some((fileTag: string) => fileTag.toLowerCase().includes(tag.toLowerCase())),
        ),
      )
    }

    if (searchText) {
      const searchLower = searchText.toLowerCase()
      results = results.filter(
        (file) =>
          file.name.toLowerCase().includes(searchLower) ||
          file.aiAnalysis?.transcript?.toLowerCase().includes(searchLower) ||
          file.aiAnalysis?.extractedText?.toLowerCase().includes(searchLower),
      )
    }

    // Generate signed URLs for file access
    const resultsWithUrls = await Promise.all(
      results.map(async (file) => {
        try {
          const [url] = await storage
            .bucket(file.bucket)
            .file(file.name)
            .getSignedUrl({
              action: "read",
              expires: Date.now() + 15 * 60 * 1000, // 15 minutes
            })

          return {
            ...file,
            downloadUrl: url,
          }
        } catch (error) {
          console.error(`Error generating signed URL for ${file.name}:`, error)
          return file
        }
      }),
    )

    res.json({
      files: resultsWithUrls,
      total: results.length,
      limit: Number.parseInt(limit.toString()),
      offset: Number.parseInt(offset.toString()),
    })
  } catch (error) {
    console.error("Search error:", error)
    res.status(500).json({ error: "Internal server error" })
  }
}

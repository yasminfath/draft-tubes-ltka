#!/bin/bash

# Status Check Script
# Shows current status of all resources

set -e

echo "📊 Archivion Media Library Status"
echo "================================="

# Check if deployment config exists
if [ ! -f "deployment-config.json" ]; then
    echo "❌ deployment-config.json not found. Run ./scripts/setup-env.sh first"
    exit 1
fi

# Read configuration
PROJECT_ID=$(jq -r '.projectId' deployment-config.json)
REGION=$(jq -r '.region' deployment-config.json)
BUCKET_NAME=$(jq -r '.bucketName' deployment-config.json)
DATABASE_ID=$(jq -r '.databaseId' deployment-config.json)
SERVICE_ACCOUNT_EMAIL=$(jq -r '.serviceAccountEmail' deployment-config.json)
SERVICE_NAME="archivion-media-library"

echo "📋 Configuration:"
echo "  Project: $PROJECT_ID"
echo "  Region: $REGION"
echo "  Bucket: $BUCKET_NAME"
echo "  Database: $DATABASE_ID"
echo ""

# Set project
gcloud config set project $PROJECT_ID

# Check Cloud Run service
echo "🚀 Cloud Run Service:"
if gcloud run services describe $SERVICE_NAME --region $REGION > /dev/null 2>&1; then
    SERVICE_URL=$(gcloud run services describe $SERVICE_NAME --region $REGION --format 'value(status.url)')
    echo "  ✅ Status: Running"
    echo "  🌐 URL: $SERVICE_URL"
    echo "  📊 Traffic: $(gcloud run services describe $SERVICE_NAME --region $REGION --format 'value(status.traffic[0].percent)')%"
else
    echo "  ❌ Status: Not deployed"
fi

echo ""

# Check Storage bucket
echo "🪣 Storage Bucket:"
if gsutil ls -b gs://$BUCKET_NAME > /dev/null 2>&1; then
    FILE_COUNT=$(gsutil ls gs://$BUCKET_NAME | wc -l)
    BUCKET_SIZE=$(gsutil du -s gs://$BUCKET_NAME | awk '{print $1}')
    echo "  ✅ Status: Active"
    echo "  📁 Files: $FILE_COUNT"
    echo "  💾 Size: $BUCKET_SIZE bytes"
else
    echo "  ❌ Status: Not found"
fi

echo ""

# Check Firestore database
echo "🗄️ Firestore Database:"
if gcloud firestore databases describe --database=$DATABASE_ID > /dev/null 2>&1; then
    echo "  ✅ Status: Active"
    echo "  🏷️ ID: $DATABASE_ID"
else
    echo "  ❌ Status: Not found"
fi

echo ""

# Check Service Account
echo "👤 Service Account:"
if gcloud iam service-accounts describe $SERVICE_ACCOUNT_EMAIL > /dev/null 2>&1; then
    echo "  ✅ Status: Active"
    echo "  📧 Email: $SERVICE_ACCOUNT_EMAIL"
else
    echo "  ❌ Status: Not found"
fi

echo ""
echo "🔧 Quick Commands:"
echo "  Deploy/Update: ./scripts/deploy.sh"
echo "  View Logs: ./scripts/logs.sh"
echo "  Update Env: ./scripts/update-env.sh"
echo "  Cleanup: ./scripts/cleanup.sh"

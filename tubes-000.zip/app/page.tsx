"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Upload, Search, Download, Eye } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface MediaFile {
  id: string
  name: string
  fileType: "image" | "video" | "audio"
  size: number
  createdAt: string
  status: "uploaded" | "processing" | "completed" | "error"
  aiAnalysis?: {
    tags: string[]
    transcript?: string
    extractedText?: string
  }
  downloadUrl?: string
}

export default function MediaLibrary() {
  const [files, setFiles] = useState<MediaFile[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedFileType, setSelectedFileType] = useState<string>("all")
  const [isUploading, setIsUploading] = useState(false)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    searchFiles()
  }, [selectedFileType])

  const searchFiles = async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams()
      if (selectedFileType !== "all") {
        params.append("fileType", selectedFileType)
      }
      if (searchQuery) {
        params.append("searchText", searchQuery)
      }

      const response = await fetch(`/api/search?${params}`)
      const data = await response.json()
      setFiles(data.files || [])
    } catch (error) {
      console.error("Search failed:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    setIsUploading(true)
    try {
      // Get signed upload URL
      const uploadResponse = await fetch("/api/upload", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fileName: file.name,
          contentType: file.type,
        }),
      })

      const { uploadUrl } = await uploadResponse.json()

      // Upload file to GCS
      await fetch(uploadUrl, {
        method: "PUT",
        body: file,
        headers: { "Content-Type": file.type },
      })

      // Refresh file list
      setTimeout(() => searchFiles(), 2000)
    } catch (error) {
      console.error("Upload failed:", error)
    } finally {
      setIsUploading(false)
    }
  }

  const getFileIcon = (fileType: string) => {
    switch (fileType) {
      case "image":
        return "🖼️"
      case "video":
        return "🎥"
      case "audio":
        return "🎵"
      default:
        return "📄"
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-100 text-green-800"
      case "processing":
        return "bg-yellow-100 text-yellow-800"
      case "error":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">AI-Powered Media Library</h1>
        <p className="text-gray-600">Upload, analyze, and manage your media files with intelligent tagging</p>
      </div>

      <Tabs defaultValue="library" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="library">Media Library</TabsTrigger>
          <TabsTrigger value="upload">Upload Files</TabsTrigger>
        </TabsList>

        <TabsContent value="upload" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Upload className="h-5 w-5" />
                Upload Media Files
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                <input
                  type="file"
                  accept="image/*,video/*,audio/*"
                  onChange={handleFileUpload}
                  disabled={isUploading}
                  className="hidden"
                  id="file-upload"
                />
                <label htmlFor="file-upload" className="cursor-pointer flex flex-col items-center gap-4">
                  <Upload className="h-12 w-12 text-gray-400" />
                  <div>
                    <p className="text-lg font-medium">{isUploading ? "Uploading..." : "Click to upload files"}</p>
                    <p className="text-sm text-gray-500">Supports images, videos, and audio files</p>
                  </div>
                </label>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="library" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Search className="h-5 w-5" />
                Search & Filter
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-4">
                <div className="flex-1">
                  <Input
                    placeholder="Search by filename, tags, or transcript..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && searchFiles()}
                  />
                </div>
                <Select value={selectedFileType} onValueChange={setSelectedFileType}>
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="image">Images</SelectItem>
                    <SelectItem value="video">Videos</SelectItem>
                    <SelectItem value="audio">Audio</SelectItem>
                  </SelectContent>
                </Select>
                <Button onClick={searchFiles} disabled={loading}>
                  <Search className="h-4 w-4 mr-2" />
                  Search
                </Button>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {loading ? (
              <div className="col-span-full text-center py-8">
                <p>Loading files...</p>
              </div>
            ) : files.length === 0 ? (
              <div className="col-span-full text-center py-8">
                <p className="text-gray-500">No files found. Upload some media to get started!</p>
              </div>
            ) : (
              files.map((file) => (
                <Card key={file.id} className="overflow-hidden">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-2xl">{getFileIcon(file.fileType)}</span>
                        <div>
                          <CardTitle className="text-sm truncate max-w-40">{file.name}</CardTitle>
                          <p className="text-xs text-gray-500">{(file.size / 1024 / 1024).toFixed(2)} MB</p>
                        </div>
                      </div>
                      <Badge className={getStatusColor(file.status)}>{file.status}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {file.aiAnalysis?.tags && file.aiAnalysis.tags.length > 0 && (
                      <div>
                        <p className="text-xs font-medium text-gray-700 mb-1">AI Tags:</p>
                        <div className="flex flex-wrap gap-1">
                          {file.aiAnalysis.tags.slice(0, 3).map((tag, index) => (
                            <Badge key={index} variant="secondary" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                          {file.aiAnalysis.tags.length > 3 && (
                            <Badge variant="outline" className="text-xs">
                              +{file.aiAnalysis.tags.length - 3}
                            </Badge>
                          )}
                        </div>
                      </div>
                    )}

                    {file.aiAnalysis?.transcript && (
                      <div>
                        <p className="text-xs font-medium text-gray-700 mb-1">Transcript:</p>
                        <p className="text-xs text-gray-600 line-clamp-2">
                          {file.aiAnalysis.transcript.substring(0, 100)}...
                        </p>
                      </div>
                    )}

                    <div className="flex gap-2 pt-2">
                      {file.downloadUrl && (
                        <Button size="sm" variant="outline" asChild>
                          <a href={file.downloadUrl} download>
                            <Download className="h-3 w-3 mr-1" />
                            Download
                          </a>
                        </Button>
                      )}
                      <Button size="sm" variant="outline">
                        <Eye className="h-3 w-3 mr-1" />
                        Details
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

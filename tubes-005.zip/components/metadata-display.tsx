"use client"

import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { CheckCircle, Clock, XCircle, AlertCircle, Loader2 } from "lucide-react"

interface MetadataDisplayProps {
  metadata: any
  fileType: string
}

export function MetadataDisplay({ metadata, fileType }: MetadataDisplayProps) {
  if (!metadata) {
    return (
      <Alert>
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>No metadata available for this file.</AlertDescription>
      </Alert>
    )
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "success":
        return <CheckCircle className="h-4 w-4 text-green-600" />
      case "processing":
        return <Loader2 className="h-4 w-4 text-blue-600 animate-spin" />
      case "pending":
        return <Clock className="h-4 w-4 text-yellow-600" />
      case "error":
        return <XCircle className="h-4 w-4 text-red-600" />
      default:
        return <AlertCircle className="h-4 w-4 text-gray-600" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "success":
        return "bg-green-100 text-green-800"
      case "processing":
        return "bg-blue-100 text-blue-800"
      case "pending":
        return "bg-yellow-100 text-yellow-800"
      case "error":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const formatDate = (dateString: string) => {
    try {
      return new Date(dateString).toLocaleString("en-US", {
        year: "numeric",
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
      })
    } catch {
      return dateString
    }
  }

  const renderGeneralMetadata = () => (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">General Information</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          {metadata.fileName && (
            <div>
              <strong>File Name:</strong> {metadata.fileName}
            </div>
          )}
          {metadata.bucket && (
            <div>
              <strong>Bucket:</strong> {metadata.bucket}
            </div>
          )}
          {metadata.contentType && (
            <div>
              <strong>Content Type:</strong> {metadata.contentType}
            </div>
          )}
          {metadata.version && (
            <div>
              <strong>Version:</strong> {metadata.version}
            </div>
          )}
          {metadata.uploadTime && (
            <div>
              <strong>Upload Time:</strong> {formatDate(metadata.uploadTime)}
            </div>
          )}
          {metadata.processedAt && (
            <div>
              <strong>Processed At:</strong> {formatDate(metadata.processedAt)}
            </div>
          )}
        </div>
        {metadata.mediaUri && (
          <div className="mt-4">
            <strong>Media URI:</strong>
            <div className="bg-gray-100 p-2 rounded text-xs font-mono break-all">{metadata.mediaUri}</div>
          </div>
        )}
      </CardContent>
    </Card>
  )

  const renderImageMetadata = () => (
    <Accordion type="single" collapsible className="w-full">
      <AccordionItem value="vision-analysis">
        <AccordionTrigger className="flex items-center gap-2">
          {getStatusIcon(metadata.visionApiStatus)}
          Vision API Analysis
          <Badge className={getStatusColor(metadata.visionApiStatus)}>{metadata.visionApiStatus}</Badge>
        </AccordionTrigger>
        <AccordionContent>
          <div className="space-y-4">
            {metadata.tags && metadata.tags.length > 0 && (
              <div>
                <h4 className="font-medium mb-2">Tags ({metadata.tags.length})</h4>
                <div className="flex flex-wrap gap-2">
                  {metadata.tags.map((tag: string, index: number) => (
                    <Badge key={index} variant="secondary">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
            {metadata.object_tags && metadata.object_tags.length > 0 && (
              <div>
                <h4 className="font-medium mb-2">Object Tags ({metadata.object_tags.length})</h4>
                <div className="flex flex-wrap gap-2">
                  {metadata.object_tags.map((tag: string, index: number) => (
                    <Badge key={index} variant="outline">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
          </div>
        </AccordionContent>
      </AccordionItem>
    </Accordion>
  )

  const renderVideoMetadata = () => (
    <Accordion type="single" collapsible className="w-full">
      <AccordionItem value="video-analysis">
        <AccordionTrigger className="flex items-center gap-2">
          {getStatusIcon(metadata.videoApiStatus)}
          Video Intelligence Analysis
          <Badge className={getStatusColor(metadata.videoApiStatus)}>{metadata.videoApiStatus}</Badge>
        </AccordionTrigger>
        <AccordionContent>
          <div className="space-y-4">
            {metadata.tags && metadata.tags.length > 0 && (
              <div>
                <h4 className="font-medium mb-2">Video Tags ({metadata.tags.length})</h4>
                <div className="flex flex-wrap gap-2">
                  {metadata.tags.map((tag: string, index: number) => (
                    <Badge key={index} variant="secondary">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
            {metadata.object_tags && metadata.object_tags.length > 0 && (
              <div>
                <h4 className="font-medium mb-2">Object Tags ({metadata.object_tags.length})</h4>
                <div className="flex flex-wrap gap-2">
                  {metadata.object_tags.map((tag: string, index: number) => (
                    <Badge key={index} variant="outline">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
          </div>
        </AccordionContent>
      </AccordionItem>

      {/* Speech Analysis for Video */}
      {metadata.speechApiStatus && (
        <AccordionItem value="speech-analysis">
          <AccordionTrigger className="flex items-center gap-2">
            {getStatusIcon(metadata.speechApiStatus)}
            Speech-to-Text Analysis
            <Badge className={getStatusColor(metadata.speechApiStatus)}>{metadata.speechApiStatus}</Badge>
          </AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4">
              {metadata.speechError && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{metadata.speechError}</AlertDescription>
                </Alert>
              )}
              {metadata.transcription && (
                <div>
                  <h4 className="font-medium mb-2">Transcription</h4>
                  <div className="bg-gray-50 p-4 rounded-md max-h-60 overflow-y-auto">
                    <p className="whitespace-pre-line text-sm">{metadata.transcription}</p>
                  </div>
                </div>
              )}
            </div>
          </AccordionContent>
        </AccordionItem>
      )}

      {/* Language Analysis for Video */}
      {metadata.languageApiStatus && (
        <AccordionItem value="language-analysis">
          <AccordionTrigger className="flex items-center gap-2">
            {getStatusIcon(metadata.languageApiStatus)}
            Natural Language Analysis
            <Badge className={getStatusColor(metadata.languageApiStatus)}>{metadata.languageApiStatus}</Badge>
          </AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4">
              {metadata.languageError && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{metadata.languageError}</AlertDescription>
                </Alert>
              )}
              {metadata.audioCategories && metadata.audioCategories.length > 0 && (
                <div>
                  <h4 className="font-medium mb-2">Categories</h4>
                  <div className="space-y-2">
                    {metadata.audioCategories.map((category: any, index: number) => (
                      <div key={index} className="flex items-center justify-between bg-gray-50 p-2 rounded">
                        <span className="text-sm">{category.name}</span>
                        <Badge variant="outline">{(category.confidence * 100).toFixed(1)}%</Badge>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              {metadata.audioEntities && metadata.audioEntities.length > 0 && (
                <div>
                  <h4 className="font-medium mb-2">Entities</h4>
                  <div className="space-y-2">
                    {metadata.audioEntities.map((entity: any, index: number) => (
                      <div key={index} className="flex items-center justify-between bg-gray-50 p-2 rounded">
                        <div>
                          <span className="text-sm font-medium">{entity.name}</span>
                          <span className="text-xs text-gray-500 ml-2">({entity.type})</span>
                        </div>
                        <Badge variant="outline">{(entity.salience * 100).toFixed(1)}%</Badge>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </AccordionContent>
        </AccordionItem>
      )}
    </Accordion>
  )

  const renderAudioMetadata = () => (
    <Accordion type="single" collapsible className="w-full">
      <AccordionItem value="speech-analysis">
        <AccordionTrigger className="flex items-center gap-2">
          {getStatusIcon(metadata.speechApiStatus)}
          Speech-to-Text Analysis
          <Badge className={getStatusColor(metadata.speechApiStatus)}>{metadata.speechApiStatus}</Badge>
        </AccordionTrigger>
        <AccordionContent>
          <div className="space-y-4">
            {metadata.speechError && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{metadata.speechError}</AlertDescription>
              </Alert>
            )}
            {metadata.transcription && (
              <div>
                <h4 className="font-medium mb-2">Transcription</h4>
                <div className="bg-gray-50 p-4 rounded-md max-h-60 overflow-y-auto">
                  <p className="whitespace-pre-line text-sm">{metadata.transcription}</p>
                </div>
              </div>
            )}
          </div>
        </AccordionContent>
      </AccordionItem>

      {metadata.languageApiStatus && (
        <AccordionItem value="language-analysis">
          <AccordionTrigger className="flex items-center gap-2">
            {getStatusIcon(metadata.languageApiStatus)}
            Natural Language Analysis
            <Badge className={getStatusColor(metadata.languageApiStatus)}>{metadata.languageApiStatus}</Badge>
          </AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4">
              {metadata.languageError && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{metadata.languageError}</AlertDescription>
                </Alert>
              )}
              {metadata.audioCategories && metadata.audioCategories.length > 0 && (
                <div>
                  <h4 className="font-medium mb-2">Categories</h4>
                  <div className="space-y-2">
                    {metadata.audioCategories.map((category: any, index: number) => (
                      <div key={index} className="flex items-center justify-between bg-gray-50 p-2 rounded">
                        <span className="text-sm">{category.name}</span>
                        <Badge variant="outline">{(category.confidence * 100).toFixed(1)}%</Badge>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              {metadata.audioEntities && metadata.audioEntities.length > 0 && (
                <div>
                  <h4 className="font-medium mb-2">Entities</h4>
                  <div className="space-y-2">
                    {metadata.audioEntities.map((entity: any, index: number) => (
                      <div key={index} className="flex items-center justify-between bg-gray-50 p-2 rounded">
                        <div>
                          <span className="text-sm font-medium">{entity.name}</span>
                          <span className="text-xs text-gray-500 ml-2">({entity.type})</span>
                        </div>
                        <Badge variant="outline">{(entity.salience * 100).toFixed(1)}%</Badge>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </AccordionContent>
        </AccordionItem>
      )}
    </Accordion>
  )

  const renderCustomFields = () => {
    // Get all fields that are not part of the standard metadata structure
    const standardFields = [
      "fileName",
      "bucket",
      "contentType",
      "uploadTime",
      "mediaUri",
      "processedAt",
      "version",
      "visionApiStatus",
      "tags",
      "object_tags",
      "videoApiStatus",
      "speechApiStatus",
      "speechError",
      "transcription",
      "languageApiStatus",
      "languageError",
      "audioCategories",
      "audioEntities",
    ]

    const customFields = Object.entries(metadata).filter(([key]) => !standardFields.includes(key))

    if (customFields.length === 0) return null

    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Additional Metadata</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {customFields.map(([key, value]) => (
              <div key={key} className="border-b pb-2 last:border-b-0">
                <div className="flex items-start justify-between">
                  <strong className="text-sm capitalize">{key.replace(/([A-Z])/g, " $1").trim()}:</strong>
                  <div className="text-sm text-right max-w-xs">
                    {typeof value === "object" ? (
                      <pre className="text-xs bg-gray-100 p-2 rounded overflow-x-auto">
                        {JSON.stringify(value, null, 2)}
                      </pre>
                    ) : typeof value === "boolean" ? (
                      <Badge variant={value ? "default" : "secondary"}>{value ? "Yes" : "No"}</Badge>
                    ) : (
                      <span className="break-words">{String(value)}</span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      {/* General Metadata */}
      {renderGeneralMetadata()}

      {/* Type-specific Metadata */}
      {fileType === "image" && renderImageMetadata()}
      {fileType === "video" && renderVideoMetadata()}
      {fileType === "audio" && renderAudioMetadata()}

      {/* Custom Fields */}
      {renderCustomFields()}
    </div>
  )
}

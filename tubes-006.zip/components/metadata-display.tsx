"use client"

import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertCircle, Music, Video, ImageIcon } from "lucide-react"

interface MetadataDisplayProps {
  metadata: any
  fileType: string
}

export function MetadataDisplay({ metadata, fileType }: MetadataDisplayProps) {
  if (!metadata) {
    return (
      <Alert>
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>No metadata available for this file.</AlertDescription>
      </Alert>
    )
  }

  const formatDate = (dateString: string) => {
    try {
      return new Date(dateString).toLocaleString("en-US", {
        year: "numeric",
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
      })
    } catch {
      return dateString
    }
  }

  const renderAudioMetadata = () => (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Music className="h-5 w-5 text-blue-600" />
          Audio Analysis
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Upload and Processing Times */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          {metadata.uploadTime && (
            <div>
              <strong>Upload Time:</strong> {formatDate(metadata.uploadTime)}
            </div>
          )}
          {metadata.processedAt && (
            <div>
              <strong>Processed At:</strong> {formatDate(metadata.processedAt)}
            </div>
          )}
        </div>

        {/* Topics */}
        {metadata.topics && metadata.topics.length > 0 && (
          <div>
            <h4 className="font-medium mb-2">Topics Discussed ({metadata.topics.length})</h4>
            <p className="text-sm text-gray-600 mb-2">This audio discusses the following topics:</p>
            <div className="flex flex-wrap gap-2">
              {metadata.topics.map((topic: string, index: number) => (
                <Badge key={index} variant="secondary" className="bg-blue-100 text-blue-800">
                  {topic}
                </Badge>
              ))}
            </div>
          </div>
        )}

        {/* Transcription */}
        {metadata.transcription && (
          <div>
            <h4 className="font-medium mb-2">Audio Transcription</h4>
            <p className="text-sm text-gray-600 mb-2">Full transcript of the audio content:</p>
            <div className="bg-gray-50 p-4 rounded-md max-h-60 overflow-y-auto">
              <p className="whitespace-pre-line text-sm">{metadata.transcription}</p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )

  const renderVideoMetadata = () => (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Video className="h-5 w-5 text-purple-600" />
          Video Analysis
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Upload and Processing Times */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          {metadata.uploadTime && (
            <div>
              <strong>Upload Time:</strong> {formatDate(metadata.uploadTime)}
            </div>
          )}
          {metadata.processedAt && (
            <div>
              <strong>Processed At:</strong> {formatDate(metadata.processedAt)}
            </div>
          )}
        </div>

        {/* Object Tags */}
        {metadata.object_tags && metadata.object_tags.length > 0 && (
          <div>
            <h4 className="font-medium mb-2">Objects Detected ({metadata.object_tags.length})</h4>
            <p className="text-sm text-gray-600 mb-2">This video contains the following objects:</p>
            <div className="flex flex-wrap gap-2">
              {metadata.object_tags.map((tag: string, index: number) => (
                <Badge key={index} variant="outline" className="border-purple-200 text-purple-700">
                  {tag}
                </Badge>
              ))}
            </div>
          </div>
        )}

        {/* General Tags */}
        {metadata.tags && metadata.tags.length > 0 && (
          <div>
            <h4 className="font-medium mb-2">General Tags ({metadata.tags.length})</h4>
            <p className="text-sm text-gray-600 mb-2">Overall content tags for this video:</p>
            <div className="flex flex-wrap gap-2">
              {metadata.tags.map((tag: string, index: number) => (
                <Badge key={index} variant="secondary" className="bg-purple-100 text-purple-800">
                  {tag}
                </Badge>
              ))}
            </div>
          </div>
        )}

        {/* Topics */}
        {metadata.topics && metadata.topics.length > 0 && (
          <div>
            <h4 className="font-medium mb-2">Topics Covered ({metadata.topics.length})</h4>
            <p className="text-sm text-gray-600 mb-2">This video covers the following topics:</p>
            <div className="flex flex-wrap gap-2">
              {metadata.topics.map((topic: string, index: number) => (
                <Badge key={index} variant="secondary" className="bg-indigo-100 text-indigo-800">
                  {topic}
                </Badge>
              ))}
            </div>
          </div>
        )}

        {/* Transcription */}
        {metadata.transcription && (
          <div>
            <h4 className="font-medium mb-2">Video Transcription</h4>
            <p className="text-sm text-gray-600 mb-2">Transcript of the audio track in this video:</p>
            <div className="bg-gray-50 p-4 rounded-md max-h-60 overflow-y-auto">
              <p className="whitespace-pre-line text-sm">{metadata.transcription}</p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )

  const renderImageMetadata = () => (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <ImageIcon className="h-5 w-5 text-green-600" />
          Image Analysis
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Upload and Processing Times */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          {metadata.uploadTime && (
            <div>
              <strong>Upload Time:</strong> {formatDate(metadata.uploadTime)}
            </div>
          )}
          {metadata.processedAt && (
            <div>
              <strong>Processed At:</strong> {formatDate(metadata.processedAt)}
            </div>
          )}
        </div>

        {/* Object Tags */}
        {metadata.object_tags && metadata.object_tags.length > 0 && (
          <div>
            <h4 className="font-medium mb-2">Objects Detected ({metadata.object_tags.length})</h4>
            <p className="text-sm text-gray-600 mb-2">This image contains the following objects:</p>
            <div className="flex flex-wrap gap-2">
              {metadata.object_tags.map((tag: string, index: number) => (
                <Badge key={index} variant="outline" className="border-green-200 text-green-700">
                  {tag}
                </Badge>
              ))}
            </div>
          </div>
        )}

        {/* General Tags */}
        {metadata.tags && metadata.tags.length > 0 && (
          <div>
            <h4 className="font-medium mb-2">General Tags ({metadata.tags.length})</h4>
            <p className="text-sm text-gray-600 mb-2">Overall content tags for this image:</p>
            <div className="flex flex-wrap gap-2">
              {metadata.tags.map((tag: string, index: number) => (
                <Badge key={index} variant="secondary" className="bg-green-100 text-green-800">
                  {tag}
                </Badge>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )

  return (
    <div className="space-y-6">
      {/* Type-specific Metadata */}
      {fileType === "image" && renderImageMetadata()}
      {fileType === "video" && renderVideoMetadata()}
      {fileType === "audio" && renderAudioMetadata()}
    </div>
  )
}

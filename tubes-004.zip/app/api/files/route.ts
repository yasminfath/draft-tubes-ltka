import { type NextRequest, NextResponse } from "next/server"
import { GoogleAuth } from "google-auth-library"

const BUCKET_NAME = process.env.GCS_BUCKET_NAME || "media-library-uploads"

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const fileType = searchParams.get("fileType")
    const searchText = searchParams.get("searchText")

    console.log("Fetching files with params:", { fileType, searchText })

    // Get files from GCS using REST API
    const files = await listFilesFromBucket()

    // Apply filters
    let filteredFiles = files

    if (fileType && fileType !== "all") {
      filteredFiles = filteredFiles.filter((file) => {
        const detectedType = getFileType(file.contentType || "")
        return detectedType === fileType
      })
    }

    if (searchText) {
      const searchLower = searchText.toLowerCase()
      filteredFiles = filteredFiles.filter((file) => file.name.toLowerCase().includes(searchLower))
    }

    console.log(`Retrieved ${filteredFiles.length} files`)

    return NextResponse.json({
      success: true,
      files: filteredFiles,
      total: filteredFiles.length,
    })
  } catch (error) {
    console.error("Error fetching files:", error)
    return NextResponse.json(
      {
        error: "Failed to fetch files",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

async function listFilesFromBucket() {
  try {
    const auth = new GoogleAuth({
      keyFilename: process.env.GOOGLE_CLOUD_KEY_FILE,
      scopes: ["https://www.googleapis.com/auth/cloud-platform"],
    })

    const client = await auth.getClient()
    const accessToken = await client.getAccessToken()

    if (!accessToken.token) {
      throw new Error("Failed to get access token")
    }

    // Use Storage JSON API to list files
    const response = await fetch(`https://storage.googleapis.com/storage/v1/b/${BUCKET_NAME}/o`, {
      headers: {
        Authorization: `Bearer ${accessToken.token}`,
      },
    })

    if (!response.ok) {
      throw new Error(`Failed to list files: ${response.statusText}`)
    }

    const data = await response.json()
    const items = data.items || []

    // Transform to our format
    return items.map((item: any) => ({
      id: item.name,
      name: item.name.split("-").slice(1).join("-"), // Remove timestamp prefix
      fileName: item.name,
      fileType: getFileType(item.contentType || ""),
      size: Number.parseInt(item.size || "0"),
      contentType: item.contentType,
      status: "completed",
      createdAt: item.timeCreated,
      downloadUrl: `https://storage.googleapis.com/${BUCKET_NAME}/${item.name}`,
      previewUrl: `https://storage.googleapis.com/${BUCKET_NAME}/${item.name}`,
      publicUrl: `https://storage.googleapis.com/${BUCKET_NAME}/${item.name}`,
    }))
  } catch (error) {
    console.error("Error listing files from bucket:", error)
    throw error
  }
}

function getFileType(contentType: string): "image" | "video" | "audio" | "unknown" {
  if (contentType.startsWith("image/")) return "image"
  if (contentType.startsWith("video/")) return "video"
  if (contentType.startsWith("audio/")) return "audio"
  return "unknown"
}

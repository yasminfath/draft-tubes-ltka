#!/bin/bash

# Deployment Script for Archivion Media Library
# Deploys the Next.js app to Cloud Run

set -e

echo "🚀 Deploying Archivion Media Library to Cloud Run"
echo "================================================="

# Check if deployment config exists
if [ ! -f "deployment-config.json" ]; then
    echo "❌ deployment-config.json not found. Please run ./scripts/setup-env.sh first"
    exit 1
fi

# Read configuration
PROJECT_ID=$(jq -r '.projectId' deployment-config.json)
REGION=$(jq -r '.region' deployment-config.json)
BUCKET_NAME=$(jq -r '.bucketName' deployment-config.json)
DATABASE_ID=$(jq -r '.databaseId' deployment-config.json)
SERVICE_ACCOUNT_EMAIL=$(jq -r '.serviceAccountEmail' deployment-config.json)
KEY_FILE=$(jq -r '.keyFile' deployment-config.json)

echo "📋 Deployment Configuration:"
echo "  Project: $PROJECT_ID"
echo "  Region: $REGION"
echo "  Bucket: $BUCKET_NAME"
echo "  Database: $DATABASE_ID"
echo ""

# Set project
gcloud config set project $PROJECT_ID

# Create Dockerfile for Cloud Run
echo "🐳 Creating Dockerfile..."
cat > Dockerfile << 'EOF'
FROM node:18-alpine

WORKDIR /app

# Copy package files
COPY package*.json ./

# Install dependencies
RUN npm ci --only=production

# Copy source code
COPY . .

# Copy service account key
COPY service-account-key.json ./

# Build the application
RUN npm run build

# Expose port
EXPOSE 3000

# Start the application
CMD ["npm", "start"]
EOF

# Create .dockerignore
echo "📝 Creating .dockerignore..."
cat > .dockerignore << 'EOF'
node_modules
.next
.git
.env*
!.env.local
README.md
Dockerfile
.dockerignore
scripts/
terraform/
*.md
EOF

# Build and deploy to Cloud Run
echo "🔨 Building and deploying to Cloud Run..."

SERVICE_NAME="archivion-media-library"

# Deploy using Cloud Build
gcloud run deploy $SERVICE_NAME \
    --source . \
    --platform managed \
    --region $REGION \
    --allow-unauthenticated \
    --service-account $SERVICE_ACCOUNT_EMAIL \
    --set-env-vars "GOOGLE_CLOUD_PROJECT_ID=$PROJECT_ID,GCS_BUCKET_NAME=$BUCKET_NAME,FIRESTORE_DATABASE_ID=$DATABASE_ID,GOOGLE_CLOUD_KEY_FILE=./service-account-key.json" \
    --memory 1Gi \
    --cpu 1 \
    --timeout 300 \
    --max-instances 10 \
    --port 3000

# Get the service URL
SERVICE_URL=$(gcloud run services describe $SERVICE_NAME --region $REGION --format 'value(status.url)')

echo ""
echo "✅ Deployment successful!"
echo ""
echo "🌐 Your Archivion Media Library is now live at:"
echo "   $SERVICE_URL"
echo ""
echo "📋 Service Details:"
echo "  Service Name: $SERVICE_NAME"
echo "  Region: $REGION"
echo "  Project: $PROJECT_ID"
echo ""
echo "🔧 To update the deployment, just run this script again!"
echo ""
echo "📊 To view logs:"
echo "   gcloud logs tail --follow --service=$SERVICE_NAME"
echo ""
echo "🗑️ To delete the service:"
echo "   gcloud run services delete $SERVICE_NAME --region $REGION"

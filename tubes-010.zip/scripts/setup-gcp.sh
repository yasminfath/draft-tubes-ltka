#!/bin/bash

# Setup script for GCP Media Library
set -e

PROJECT_ID=${1:-"your-project-id"}
BUCKET_NAME=${2:-"media-library-uploads"}
REGION=${3:-"us-central1"}

echo "Setting up GCP Media Library for project: $PROJECT_ID"

# Set project
gcloud config set project $PROJECT_ID

# Enable required APIs
echo "Enabling required APIs..."
gcloud services enable storage.googleapis.com
gcloud services enable firestore.googleapis.com
gcloud services enable run.googleapis.com

# Create GCS bucket
echo "Creating GCS bucket: $BUCKET_NAME"
gsutil mb -p $PROJECT_ID -c STANDARD -l $REGION gs://$BUCKET_NAME

# Set bucket permissions (make it publicly readable)
echo "Setting bucket permissions..."
gsutil iam ch allUsers:objectViewer gs://$BUCKET_NAME

# Enable CORS for the bucket
echo "Setting CORS policy..."
cat > cors.json << EOF
[
  {
    "origin": ["*"],
    "method": ["GET", "HEAD", "PUT", "POST", "DELETE"],
    "responseHeader": ["*"],
    "maxAgeSeconds": 3600
  }
]
EOF

gsutil cors set cors.json gs://$BUCKET_NAME
rm cors.json

# Create Firestore database
echo "Creating Firestore database..."
gcloud firestore databases create --region=$REGION

# Create service account
echo "Creating service account..."
gcloud iam service-accounts create media-library-service \
    --display-name="Media Library Service Account"

# Grant permissions to service account
echo "Granting permissions..."
gcloud projects add-iam-policy-binding $PROJECT_ID \
    --member="serviceAccount:media-library-service@$PROJECT_ID.iam.gserviceaccount.com" \
    --role="roles/storage.objectAdmin"

gcloud projects add-iam-policy-binding $PROJECT_ID \
    --member="serviceAccount:media-library-service@$PROJECT_ID.iam.gserviceaccount.com" \
    --role="roles/datastore.user"

# Create and download service account key
echo "Creating service account key..."
gcloud iam service-accounts keys create ./service-account-key.json \
    --iam-account=media-library-service@$PROJECT_ID.iam.gserviceaccount.com

echo "Setup complete!"
echo "Bucket name: $BUCKET_NAME"
echo "Service account key saved to: ./service-account-key.json"
echo ""
echo "Update your .env.local file with:"
echo "GOOGLE_CLOUD_PROJECT_ID=$PROJECT_ID"
echo "GOOGLE_CLOUD_KEY_FILE=./service-account-key.json"
echo "GCS_BUCKET_NAME=$BUCKET_NAME"
